@echo off
setlocal
cd /d "%~dp0"
set "ENV=.venv"
if exist "luna_environment.txt" set /p ENV=<"luna_environment.txt"
if not exist "%ENV%\Scripts\python.exe" (
  start "" "%~dp0installer.pyw"
  exit /b 0
)
if exist "%ENV%\Scripts\pythonw.exe" (start "" "%~dp0%ENV%\Scripts\pythonw.exe" "%~dp0app.py") else (start "" "%~dp0%ENV%\Scripts\python.exe" "%~dp0app.py")
exit /b 0
