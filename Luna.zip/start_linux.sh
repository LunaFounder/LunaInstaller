#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
PYTHON="${PYTHON:-python3}"
if ! command -v "$PYTHON" >/dev/null 2>&1; then
  echo "Python 3 is required."
  exit 1
fi
if [ ! -d ".venv-linux" ]; then
  "$PYTHON" -m venv ".venv-linux"
fi
if [ ! -f ".venv-linux/.luna_deps_ready" ]; then
  ".venv-linux/bin/python" -m pip install --upgrade pip
  ".venv-linux/bin/python" -m pip install -r requirements-linux.txt
  touch ".venv-linux/.luna_deps_ready"
fi
exec ".venv-linux/bin/python" app.py
