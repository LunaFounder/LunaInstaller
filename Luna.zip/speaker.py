from pathlib import Path
import json
import numpy as np

try:
    import torch
    from speechbrain.inference.speaker import EncoderClassifier
except Exception:
    torch = None
    EncoderClassifier = None


class SpeakerManager:
    def __init__(self, profile_dir="speaker_profiles", threshold=0.62):
        self.profile_dir = Path(profile_dir)
        self.profile_dir.mkdir(exist_ok=True)
        self.threshold = threshold
        self.encoder = None
        self.embeddings = {}

    def available(self):
        return EncoderClassifier is not None and torch is not None

    def load(self):
        if not self.available():
            return False
        if self.encoder is None:
            self.encoder = EncoderClassifier.from_hparams(
                source="speechbrain/spkrec-ecapa-voxceleb",
                savedir="pretrained_models/spkrec-ecapa-voxceleb"
            )
        for wav in self.profile_dir.glob("*.npy"):
            self.embeddings[wav.stem] = np.load(wav)
        return True

    def embed_file(self, wav_path):
        self.load()
        if self.encoder is None:
            raise RuntimeError("Speaker ID dependencies are unavailable.")
        signal = self._read(wav_path)
        emb = self.encoder.encode_batch(signal).squeeze().detach().cpu().numpy()
        return emb / (np.linalg.norm(emb) + 1e-9)

    def _read(self, wav_path):
        import torchaudio
        signal, sr = torchaudio.load(str(wav_path))
        if signal.shape[0] > 1:
            signal = signal.mean(dim=0, keepdim=True)
        if sr != 16000:
            signal = torchaudio.functional.resample(signal, sr, 16000)
        return signal

    def enroll(self, name, wav_path):
        emb = self.embed_file(wav_path)
        np.save(self.profile_dir / f"{name}.npy", emb)
        self.embeddings[name] = emb

    def identify(self, wav_path):
        if not self.embeddings:
            return "default", 0.0
        emb = self.embed_file(wav_path)
        best_name, best_score = "default", -1.0
        for name, ref in self.embeddings.items():
            score = float(np.dot(emb, ref))
            if score > best_score:
                best_name, best_score = name, score
        if best_score >= self.threshold:
            return best_name, best_score
        return "default", best_score
