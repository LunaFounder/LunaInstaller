import threading
import time
import pyautogui


class MinecraftAssist:
    def __init__(self, event_cb):
        self.event_cb = event_cb
        self.running = False
        self.stop_event = threading.Event()
        self.thread = None

    def _ocr_text(self):
        try:
            import pytesseract
            image = pyautogui.screenshot()
            return pytesseract.image_to_string(image).lower()
        except Exception as exc:
            self.event_cb(f"Minecraft assist screen check unavailable: {exc}")
            return ""

    def start(self):
        if self.running:
            self.event_cb("Minecraft assist is already running.")
            return
        self.running = True
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        self.event_cb("Minecraft assist started. Luna will watch for the Respawn screen and ask before acting.")

    def stop(self):
        self.stop_event.set()
        self.running = False
        self.event_cb("Minecraft assist stopped.")

    def confirm_respawn(self):
        if not self.running:
            self.event_cb("Minecraft assist is not running.")
            return
        # User-confirmed step only.
        try:
            w, h = pyautogui.size()
            pyautogui.click(w // 2, int(h * 0.60))
            time.sleep(1.0)
            pyautogui.press("/")
            pyautogui.write("home", interval=0.04)
            pyautogui.press("enter")
            self.event_cb("Minecraft assist completed the confirmed Respawn → /home steps.")
        except Exception as exc:
            self.event_cb(f"Minecraft assist action failed: {exc}")

    def _loop(self):
        last_detected = 0.0
        while not self.stop_event.is_set():
            text = self._ocr_text()
            now = time.time()
            if "respawn" in text and now - last_detected > 8:
                last_detected = now
                self.event_cb(("MINECRAFT_RESPAWN_CONFIRM", "Minecraft Respawn detected. Confirm to click Respawn, type /home, and press Enter."))
            time.sleep(2.5)
