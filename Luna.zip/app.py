import sys, threading, math, ctypes, os
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QAbstractNativeEventFilter
from PySide6.QtGui import QColor, QPainter, QFont, QPixmap
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QFrame, QDialog, QListWidget, QLineEdit, QComboBox, QMessageBox
from assistant import VoiceAssistant
from voice_apps import scan_apps, get_commands, set_command, remove_command

class VoiceAppsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Luna — Voice Activated Apps')
        self.resize(520, 420)
        self.setStyleSheet('QDialog{background:#161923;color:white} QLabel{color:white} QLineEdit,QComboBox,QListWidget{background:#202433;color:white;border:1px solid #384055;border-radius:5px;padding:5px} QPushButton{background:#8e5bb7;color:white;border:0;border-radius:5px;padding:7px 10px}')
        self.apps = scan_apps()
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel('Choose an app and assign the phrase Luna should listen for.'))
        self.app_combo = QComboBox(); self.app_combo.addItems([Path(p).stem for p in self.apps.values()]); lay.addWidget(self.app_combo)
        self.phrase = QLineEdit(); self.phrase.setPlaceholderText('Voice command, e.g. "open spotify"'); lay.addWidget(self.phrase)
        row=QHBoxLayout(); save=QPushButton('Save Command'); remove=QPushButton('Remove Command'); row.addWidget(save); row.addWidget(remove); lay.addLayout(row)
        self.list = QListWidget(); lay.addWidget(self.list,1)
        close=QPushButton('Close'); close.clicked.connect(self.accept); lay.addWidget(close)
        save.clicked.connect(self.save_cmd); remove.clicked.connect(self.remove_cmd)
        self.refresh()
        self.app_combo.currentTextChanged.connect(self.load_selected)
        self.load_selected(self.app_combo.currentText())
    def refresh(self):
        self.list.clear()
        for phrase, path in sorted(get_commands().items()): self.list.addItem(f'{phrase}  →  {Path(path).stem}')
    def load_selected(self, name):
        for phrase, path in get_commands().items():
            if Path(path).stem.lower()==name.lower(): self.phrase.setText(phrase); return
        self.phrase.clear()
    def save_cmd(self):
        try:
            set_command(self.app_combo.currentText(), self.phrase.text())
            self.refresh(); QMessageBox.information(self,'Luna','Voice command saved.')
        except Exception as e: QMessageBox.warning(self,'Luna',str(e))
    def remove_cmd(self):
        phrase=self.phrase.text().strip()
        if phrase:
            remove_command(phrase); self.refresh(); self.phrase.clear()

class WindowsPowerEventFilter(QAbstractNativeEventFilter):
    WM_POWERBROADCAST = 0x0218; PBT_APMRESUMEAUTOMATIC = 0x0012; PBT_APMRESUMECRITICAL = 0x0006
    def __init__(self, callback): super().__init__(); self.callback=callback
    def nativeEventFilter(self, eventType, message):
        try:
            if sys.platform == 'win32' and eventType == 'windows_generic_MSG':
                msg=ctypes.wintypes.MSG.from_address(int(message))
                if msg.message==self.WM_POWERBROADCAST and msg.wParam in (self.PBT_APMRESUMEAUTOMATIC,self.PBT_APMRESUMECRITICAL): QTimer.singleShot(1500,self.callback)
        except Exception: pass
        return False,0

class Avatar(QWidget):
    def __init__(self):
        super().__init__(); self.t=0.0; self.setFixedSize(105,126); self.setAttribute(Qt.WA_TranslucentBackground)
        self.pixmap=QPixmap(str(Path(__file__).resolve().parent/'assets'/'luna_v1.png')); self.timer=QTimer(self); self.timer.timeout.connect(self.update_anim); self.timer.start(40)
    def update_anim(self): self.t+=0.06; self.update()
    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing); bob=math.sin(self.t)*2.0; pulse=(math.sin(self.t*1.7)+1)*0.5; p.setPen(Qt.NoPen); p.setBrush(QColor(40,255,190,int(18+pulse*18))); p.drawEllipse(14,10+bob,78,102); p.drawPixmap(self.rect().adjusted(0,int(bob),0,int(bob)),self.pixmap)

class MainWindow(QWidget):
    def __init__(self):
        super().__init__(); self.setWindowTitle('Luna — Version 1'); flags=Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint; self.setWindowFlags(flags|Qt.Tool if sys.platform=='win32' else flags); self.setAttribute(Qt.WA_TranslucentBackground); self.resize(300,190); self.pending_action=None
        self.card=QFrame(); self.card.setStyleSheet('QFrame{background:rgba(20,20,30,235);border:1px solid rgba(255,255,255,35);border-radius:5px;color:white} QLabel{color:white} QPushButton{background:#8e5bb7;color:white;border:0;border-radius:5px;padding:4px 7px} QPushButton:hover{background:#a971d0}')
        self.listen_indicator=QLabel('●  STARTING'); self.listen_indicator.setFont(QFont('Segoe UI',9,QFont.Bold)); self.listen_indicator.setStyleSheet('color:#b7b7c9'); self.status=QLabel('Starting…'); self.status.setWordWrap(True); self.status.setFont(QFont('Segoe UI',8)); self.log=QLabel(''); self.log.setWordWrap(True); self.log.setMaximumHeight(38)
        self.confirm_box=QFrame(); cl=QHBoxLayout(self.confirm_box); self.confirm_box.hide(); self.confirm_text=QLabel(''); self.confirm_text.setWordWrap(True); yes=QPushButton('Confirm'); no=QPushButton('Cancel'); yes.clicked.connect(lambda:self.respond(True)); no.clicked.connect(lambda:self.respond(False)); cl.addWidget(self.confirm_text,1); cl.addWidget(yes); cl.addWidget(no)
        settings=QPushButton('Settings'); settings.clicked.connect(self.open_settings); mc=QPushButton('Minecraft Assist'); mc.clicked.connect(self.toggle_minecraft_assist); stop=QPushButton('Quit'); stop.clicked.connect(self.close)
        layout=QVBoxLayout(self.card); layout.setContentsMargins(6,6,6,6); layout.addWidget(self.listen_indicator); layout.addWidget(self.status); layout.addWidget(self.log); layout.addWidget(self.confirm_box); layout.addWidget(settings); layout.addWidget(mc); layout.addWidget(stop)
        outer=QHBoxLayout(self); outer.setContentsMargins(0,0,0,0); outer.addWidget(Avatar()); outer.addWidget(self.card,1); self.move_to_corner(); self.assistant=VoiceAssistant(self.handle_assistant_event); threading.Thread(target=self.loop,daemon=True).start()
    def move_to_corner(self): screen=QApplication.primaryScreen().availableGeometry(); self.move(screen.left()+6,screen.bottom()-self.height()-6)
    def open_settings(self):
        dlg=QDialog(self)
        dlg.setWindowTitle('Luna — Settings')
        dlg.resize(360,220)
        dlg.setStyleSheet('QDialog{background:#161923;color:white} QLabel{color:white} QPushButton{background:#8e5bb7;color:white;border:0;border-radius:6px;padding:8px 10px}')
        lay=QVBoxLayout(dlg)
        title=QLabel('Settings')
        title.setFont(QFont('Segoe UI',12,QFont.Bold))
        lay.addWidget(title)
        desc=QLabel('Configure how Luna responds and launches apps.')
        desc.setWordWrap(True)
        lay.addWidget(desc)
        voice=QPushButton('Voice Activated Apps')
        voice.clicked.connect(lambda: VoiceAppsDialog(dlg).exec())
        lay.addWidget(voice)
        close=QPushButton('Close')
        close.clicked.connect(dlg.accept)
        lay.addWidget(close)
        dlg.exec()
    def open_voice_apps(self): VoiceAppsDialog(self).exec()
    def toggle_minecraft_assist(self):
        if self.minecraft_assist.running: self.minecraft_assist.stop()
        else: self.minecraft_assist.start()
    def handle_assistant_event(self,msg): QTimer.singleShot(0,lambda:self._handle_assistant_event(msg))
    def _handle_assistant_event(self,msg):
        if msg == 'MINECRAFT_ASSIST_START':
            self.minecraft_assist.start(); return
        if msg == 'MINECRAFT_ASSIST_STOP':
            self.minecraft_assist.stop(); return
        if isinstance(msg,tuple) and msg[0]=='MINECRAFT_RESPAWN_CONFIRM':
            self.pending_action={'type':'minecraft_respawn_assist'}; self.confirm_text.setText(msg[1]); self.confirm_box.show(); return
        if isinstance(msg,tuple) and msg[0]=='CONFIRM': self.pending_action=msg[1]; self.confirm_text.setText('Confirm this action?\n\n'+__import__('actions').describe(self.pending_action)); self.confirm_box.show(); return
        text=str(msg); self.status.setText(text); self.log.setText(text); low=text.lower()
        if 'listening for your command' in low or "i'm listening" in low: self.listen_indicator.setText('●  LISTENING'); self.listen_indicator.setStyleSheet('color:#55f0a5')
        elif 'say "hey luna"' in low: self.listen_indicator.setText('●  STANDBY'); self.listen_indicator.setStyleSheet('color:#7ddcff')
        elif 'starting' in low or 'reconnecting' in low: self.listen_indicator.setText('●  STARTING'); self.listen_indicator.setStyleSheet('color:#b7b7c9')
        elif 'error' in low or 'failed' in low or 'unavailable' in low: self.listen_indicator.setText('●  OFFLINE'); self.listen_indicator.setStyleSheet('color:#ff7f8a')
        else: self.listen_indicator.setText('●  READY'); self.listen_indicator.setStyleSheet('color:#9be7c4')
    def handle_wake(self):
        try:
            if self.assistant and not self.assistant.stop_requested:
                self.status.setText('Computer woke up — Luna is reconnecting...'); threading.Thread(target=self.assistant.handle_wake,daemon=True).start()
        except Exception as e: self.status.setText(f'Wake recovery error: {e}')
    def loop(self):
        while not self.assistant.stop_requested:
            try: self.assistant.run_once()
            except Exception as e: self.handle_assistant_event(f'Error: {e}')
    def respond(self,yes):
        self.confirm_box.hide()
        if self.pending_action and self.pending_action.get('type') == 'minecraft_respawn_assist':
            if yes: self.minecraft_assist.confirm_respawn()
            else: self.handle_assistant_event('Minecraft assist action cancelled.')
            self.pending_action=None
            return
        self.assistant.confirm_action(yes)
        self.pending_action=None
    def closeEvent(self,e): self.minecraft_assist.stop(); self.assistant.stop(); e.accept()

if __name__=='__main__':
    app=QApplication(sys.argv); app.setApplicationName('Luna'); app.setDesktopFileName('luna'); w=MainWindow(); w.show(); sys.exit(app.exec())
