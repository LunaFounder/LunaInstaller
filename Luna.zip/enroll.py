import argparse
import os
import tempfile
import sounddevice as sd
import soundfile as sf
from speaker import SpeakerManager

parser = argparse.ArgumentParser()
parser.add_argument("--name", required=True)
parser.add_argument("--seconds", type=int, default=8)
args = parser.parse_args()

print(f"Speak naturally for {args.seconds} seconds. Recording...")
audio = sd.rec(int(args.seconds * 16000), samplerate=16000, channels=1, dtype="float32")
sd.wait()

with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
    path = f.name

sf.write(path, audio, 16000)
try:
    mgr = SpeakerManager()
    mgr.enroll(args.name, path)
    print(f"Enrolled speaker: {args.name}")
finally:
    os.unlink(path)
