import json
import os
from pathlib import Path
import subprocess

CONFIG = Path(__file__).resolve().parent / 'voice_apps.json'
START_MENU_DIRS = [
    Path(os.environ.get('APPDATA','')) / 'Microsoft/Windows/Start Menu/Programs',
    Path(os.environ.get('ProgramData','')) / 'Microsoft/Windows/Start Menu/Programs',
]


def _load():
    try:
        return json.loads(CONFIG.read_text(encoding='utf-8'))
    except Exception:
        return {}


def _save(data):
    CONFIG.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')


def scan_apps():
    found = {}
    for root in START_MENU_DIRS:
        if not root.exists():
            continue
        for p in root.rglob('*'):
            if p.is_file() and p.suffix.lower() in {'.lnk', '.exe'}:
                key = p.stem.lower()
                found.setdefault(key, str(p))
    # Common Windows apps that may not appear as normal Start Menu shortcuts.
    win = Path(os.environ.get('WINDIR', r'C:\Windows'))
    for p in [win/'System32/notepad.exe', win/'System32/calc.exe', win/'explorer.exe']:
        if p.exists():
            found.setdefault(p.stem.lower(), str(p))
    return {k: found[k] for k in sorted(found)}


def get_commands():
    return _load()


def set_command(app_name, phrase):
    data = _load()
    app_name = app_name.strip()
    phrase = phrase.strip().lower()
    if not app_name or not phrase:
        raise ValueError('Application and voice command are required.')
    apps = scan_apps()
    target = None
    for name, path in apps.items():
        if name == app_name.lower() or Path(path).stem.lower() == app_name.lower():
            target = path
            break
    if target is None:
        raise ValueError('Application not found.')
    data[phrase] = target
    _save(data)


def remove_command(phrase):
    data = _load()
    data.pop(phrase.strip().lower(), None)
    _save(data)


def resolve_command(text):
    low = text.lower().strip()
    data = _load()
    path = data.get(low)
    if path:
        return path
    # Allow natural language such as "open my music app" when the configured phrase is "music app".
    for phrase, candidate in data.items():
        if phrase in low and low.startswith(('open ', 'launch ', 'start ')):
            return candidate
    return None


def launch_path(path):
    if os.name == 'nt':
        os.startfile(path)
    else:
        subprocess.Popen([path])
