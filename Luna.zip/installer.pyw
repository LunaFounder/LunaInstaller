import os
import sys
import subprocess
import threading
import tkinter as tk
from tkinter import messagebox
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQ = ROOT / 'requirements.txt'
ENV_FILE = ROOT / 'luna_environment.txt'

class Installer:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Luna — Installer')
        self.root.geometry('560x360')
        self.root.resizable(False, False)
        self.root.configure(bg='#14151d')

        tk.Label(self.root, text='Luna', font=('Segoe UI', 24, 'bold'), fg='white', bg='#14151d').pack(pady=(22, 4))
        tk.Label(self.root, text='Version 1 • Minecraft Assist • Voice Activated Apps', font=('Segoe UI', 10), fg='#b9bfd3', bg='#14151d').pack()

        self.status = tk.StringVar(value='Ready to install Luna.')
        tk.Label(self.root, textvariable=self.status, font=('Segoe UI', 10), fg='#dfe4f5', bg='#14151d', wraplength=500).pack(pady=22)

        self.progress = tk.DoubleVar(value=0)
        tk.Scale(self.root, variable=self.progress, from_=0, to=100, orient='horizontal', length=470,
                 showvalue=False, state='disabled', highlightthickness=0, troughcolor='#292d3d', bg='#14151d').pack()

        row = tk.Frame(self.root, bg='#14151d')
        row.pack(pady=28)
        self.install_btn = tk.Button(row, text='Install Luna', command=self.start, width=18, height=2,
                                     bg='#8e5bb7', fg='white', activebackground='#a971d0', relief='flat')
        self.install_btn.pack(side='left', padx=8)
        tk.Button(row, text='Close', command=self.root.destroy, width=12, height=2,
                  bg='#2b3040', fg='white', activebackground='#3a4054', relief='flat').pack(side='left', padx=8)

        self.root.mainloop()

    def choose_env(self):
        preferred = ROOT / '.venv'
        candidates = [preferred] + [ROOT / f'.venv_{i}' for i in range(2, 11)]
        for p in candidates:
            if p.exists() and (p / 'Scripts' / 'python.exe').exists():
                return p
            try:
                p.mkdir(exist_ok=True)
                return p
            except OSError:
                continue
        raise RuntimeError('Windows would not allow Luna to create a virtual environment in this folder.')

    def run(self):
        try:
            self.install_btn.config(state='disabled')
            self.status.set('Creating Luna environment...')
            env = self.choose_env()
            py = env / 'Scripts' / 'python.exe'
            if not py.exists():
                subprocess.run([sys.executable, '-m', 'venv', str(env)], check=True)

            self.progress.set(20)
            self.status.set('Upgrading pip...')
            subprocess.run([str(py), '-m', 'pip', 'install', '--upgrade', 'pip'], check=True)

            self.progress.set(40)
            self.status.set('Installing Luna dependencies... This can take several minutes.')
            subprocess.run([str(py), '-m', 'pip', 'install', '-r', str(REQ)], check=True)

            self.progress.set(95)
            ENV_FILE.write_text(env.name, encoding='utf-8')
            # Create a persistent Start Menu/desktop shortcut so Luna can be pinned to the taskbar.
            ps1 = ROOT / 'create_luna_shortcuts.ps1'
            if ps1.exists():
                try:
                    subprocess.run(['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(ps1)], check=False, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                except Exception:
                    pass
            (ROOT / 'install_complete.txt').write_text('Luna installation completed.\n', encoding='utf-8')
            self.progress.set(100)
            self.status.set('Luna is installed. Starting Luna...')
            self.root.after(700, lambda: self.launch(env, py))
        except subprocess.CalledProcessError as e:
            self.status.set('Installation failed. See the error dialog for details.')
            self.install_btn.config(state='normal')
            messagebox.showerror('Luna Installer', f'An installation command failed.\n\nCommand returned exit code {e.returncode}.\n\nTry running the installer again from a normal local folder such as Documents.')
        except Exception as e:
            self.status.set('Installation failed.')
            self.install_btn.config(state='normal')
            messagebox.showerror('Luna Installer', str(e))

    def launch(self, env, py):
        try:
            subprocess.Popen([str(py), str(ROOT / 'app.py')], cwd=str(ROOT))
            self.root.destroy()
        except Exception as e:
            self.install_btn.config(state='normal')
            self.status.set('Installed, but Luna could not be started automatically.')
            messagebox.showwarning('Luna', f'Installation completed. Start Luna with start.bat.\n\n{e}')

    def start(self):
        threading.Thread(target=self.run, daemon=True).start()

Installer()
