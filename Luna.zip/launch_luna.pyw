import subprocess
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
ROOT=Path(__file__).resolve().parent
name=".venv"
p=ROOT/"luna_environment.txt"
if p.exists():
    try: name=p.read_text(encoding="utf-8").strip() or name
    except Exception: pass
ENV=ROOT/name; PYW=ENV/"Scripts"/"pythonw.exe"; PY=ENV/"Scripts"/"python.exe"; APP=ROOT/"app.py"
exe=PYW if PYW.exists() else PY
if not exe.exists():
    r=tk.Tk(); r.withdraw(); messagebox.showerror("Luna","Luna is not installed yet. Please run installer.pyw."); r.destroy(); raise SystemExit(1)
subprocess.Popen([str(exe),str(APP)],cwd=str(ROOT))
