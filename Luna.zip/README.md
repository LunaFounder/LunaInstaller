# Luna — Voice PC Assistant

Luna is a confirmation-gated Windows voice assistant. Say **"listen up"**, give a command, and Luna shows the exact action before doing it.

## Desktop, browser, and app control

Luna can launch common desktop apps (including Discord, Minecraft, Fortnite, Roblox, Chrome, Edge, and Notepad), open websites, search the web, type text, send hotkeys/keys, click or double-click screen coordinates, scroll, open folders, take screenshots, and run non-elevated PowerShell commands after confirmation.

These controls let Luna handle many ordinary browser and desktop workflows. Because browser pages and games change constantly, arbitrary website/game tasks may need a sequence of confirmed clicks/typing rather than a single command.

### Games
Luna can launch and perform ordinary UI actions where appropriate. It is **not intended to cheat, bot gameplay, exploit games, bypass anti-cheat, or evade game security**. Fortnite, Roblox, Minecraft servers, and other games may restrict automation.

## Installation

Use `installer.pyw` for the graphical installer. The installer keeps the base install smaller and offers speaker identification as an optional large download.

## Optional local AI

Set `OLLAMA_MODEL` in `.env` to let a local Ollama model turn more natural requests into Luna actions. Every resulting action still requires on-screen confirmation.


Screen analysis: say "Hey Luna" then "What's on my screen?". Screen capture and OCR are local.

TASKBAR PINNING
After installation, Luna creates a Start Menu shortcut named "Luna" and a desktop shortcut.
To pin Luna to the Windows taskbar: open Start, search for Luna, right-click Luna, then choose "Pin to taskbar".
Windows controls taskbar pinning, so Luna creates the proper app shortcut rather than silently changing your taskbar.
