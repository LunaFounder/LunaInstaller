@echo off
setlocal
cd /d "%~dp0"
if not exist "%SystemRoot%\py.exe" if not exist "%ProgramFiles%\Python312\python.exe" if not exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
  echo Python 3 was not found.
  echo Please install Python 3.11 or newer with "Add Python to PATH" enabled.
  pause
  exit /b 1
)
start "Luna Installer" "%~dp0installer.pyw"
exit /b 0
