import sys, threading, math, os, traceback
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QRectF, QPropertyAnimation, QEasingCurve, QPointF
from PySide6.QtGui import QColor, QPainter, QFont, QPixmap, QIcon
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QHBoxLayout, QVBoxLayout, QFrame, QDialog, QComboBox, QLineEdit, QListWidget, QMessageBox, QFileDialog, QCheckBox

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
STARTUP_LOG = ROOT / 'luna_startup.log'

def log_error(prefix, exc=None):
    try:
        with STARTUP_LOG.open('a', encoding='utf-8') as f:
            f.write('\n' + '='*70 + '\n' + prefix + '\n')
            if exc: f.write(''.join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
    except Exception:
        pass

class LunaVisual(QWidget):
    """Animated Luna artwork. The user can select a local image as the Premium character image."""
    def __init__(self):
        super().__init__()
        self.phase = 0.0
        self.head_turn = 0.0
        self.expression = 'neutral'
        self.blink = 0.0
        self._expr_index = 0
        self.setFixedSize(250, 223)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.image_path = ROOT/'assets'/'luna_v2_cute.png' if (ROOT/'assets'/'luna_v2_cute.png').exists() else ROOT/'assets'/'luna_v1.png'
        self.pixmap = QPixmap(str(self.image_path))
        self.anim_enabled = True
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(50)

    def set_image(self, path):
        pm = QPixmap(str(path))
        if not pm.isNull():
            self.image_path = Path(path)
            self.pixmap = pm
            self.update()
            return True
        return False

    def set_expression(self, expression):
        expression = str(expression).lower().strip()
        if expression not in {'neutral', 'happy', 'surprised', 'focused', 'sad', 'blink'}:
            expression = 'neutral'
        self.expression = expression
        self.update()

    def tick(self):
        self.phase += 0.05
        if self.anim_enabled:
            # Small head turn: Luna gently looks left/right instead of staying perfectly static.
            self.head_turn = 3.2 * math.sin(self.phase * 0.55)
            # Natural blink cycle.
            blink_phase = (self.phase % 12.0)
            self.blink = 1.0 if 8.0 < blink_phase < 8.35 else 0.0
            # Cycle through subtle facial moods. These are overlays on top of the user's image.
            cycle = int(self.phase // 18.0) % 4
            self._expr_index = cycle
            self.expression = ('neutral', 'happy', 'focused', 'surprised')[cycle]
        else:
            self.head_turn = 0.0
            self.blink = 0.0
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if self.pixmap.isNull():
            return

        # Gentle breathing/bobbing plus a tiny rotation to simulate a head turn.
        bob = 2.0 * math.sin(self.phase * 1.3) if self.anim_enabled else 0.0
        scale = 1.0 + 0.006 * math.sin(self.phase * 1.1) if self.anim_enabled else 1.0
        target = self.rect().adjusted(0, int(bob), 0, int(-bob))
        if scale != 1.0:
            w = int(target.width()*scale); h = int(target.height()*scale)
            target = QRectF((self.width()-w)/2, (self.height()-h)/2, w, h).toRect()

        center = QPointF(self.width()/2, self.height()/2)
        p.save()
        p.scale(self.width()/340.0, self.height()/303.0)
        p.translate(center)
        if self.anim_enabled:
            p.rotate(self.head_turn)
        p.translate(-center)
        p.drawPixmap(target, self.pixmap)

        # Facial-expression overlays. The base artwork remains unchanged and can be swapped
        # by the user; these small strokes add blink/smile/blush/surprise cues.
        face_x1, face_x2 = 145.0, 196.0
        eye_y = 129.0
        p.setPen(Qt.NoPen)
        if self.expression == 'happy':
            p.setPen(QColor(55, 20, 30, 210)); p.setBrush(Qt.NoBrush)
            pen = p.pen(); pen.setWidthF(2.2); p.setPen(pen)
            p.drawArc(QRectF(face_x1-8, eye_y-4, 18, 10), 200*16, 140*16)
            p.drawArc(QRectF(face_x2-8, eye_y-4, 18, 10), 200*16, 140*16)
            p.setPen(QColor(255, 120, 160, 80)); p.setBrush(QColor(255, 100, 140, 55))
            p.drawEllipse(QRectF(face_x1-15, eye_y+12, 13, 7)); p.drawEllipse(QRectF(face_x2+3, eye_y+12, 13, 7))
        elif self.expression == 'surprised':
            p.setPen(QColor(55, 20, 30, 210)); p.setBrush(Qt.NoBrush)
            pen = p.pen(); pen.setWidthF(2.0); p.setPen(pen)
            p.drawEllipse(QRectF(face_x1-2, eye_y-5, 15, 15)); p.drawEllipse(QRectF(face_x2-2, eye_y-5, 15, 15))
        elif self.expression == 'sad':
            p.setPen(QColor(55, 20, 30, 170)); p.setBrush(Qt.NoBrush)
            pen = p.pen(); pen.setWidthF(2.0); p.setPen(pen)
            p.drawArc(QRectF(167, 145, 18, 12), 20*16, 140*16)

        if self.blink > 0 or self.expression == 'blink':
            p.setPen(QColor(45, 20, 28, 225)); p.setBrush(Qt.NoBrush)
            pen = p.pen(); pen.setWidthF(2.6); p.setPen(pen)
            p.drawLine(QPointF(face_x1-5, eye_y+2), QPointF(face_x1+8, eye_y+1))
            p.drawLine(QPointF(face_x2-5, eye_y+1), QPointF(face_x2+8, eye_y+2))

        p.restore()

        glow = int(10 + (math.sin(self.phase*1.2)+1)*8) if self.anim_enabled else 8
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(70,255,200,glow))
        p.drawEllipse(QRectF(110,55,120,150))

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Luna — Luna Founder')
        icon=ROOT/'assets'/'luna.ico'
        if icon.exists(): self.setWindowIcon(QIcon(str(icon)))
        flags=Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(250,223)
        self.pending_action=None; self.assistant=None; self.minecraft_assist=None

        self.canvas=LunaVisual()
        self.canvas.setParent(self)

        self.status=QLabel('Luna Founder\nReady')
        self.status.setFont(QFont('Segoe UI', 8, QFont.Bold)); self.status.setStyleSheet('color:white;background:transparent')
        self.status.setFixedHeight(32)
        self.indicator=QLabel('●')
        self.indicator.setFont(QFont('Segoe UI', 12, QFont.Bold)); self.indicator.setStyleSheet('color:#44ffc1;background:transparent')

        self.mic=QPushButton('🎙'); self.mic.setFixedSize(38,38)
        self.mic.setStyleSheet('QPushButton{background:#0d9d82;color:white;border:0;border-radius:19px;font-size:16px} QPushButton:hover{background:#12b694}')
        self.mic.clicked.connect(self.toggle_listening)
        self.settings=QPushButton('⚙'); self.settings.setFixedSize(32,32)
        self.settings.setStyleSheet('QPushButton{background:#17252b;color:#d8ffff;border:1px solid #24444d;border-radius:16px;font-size:14px} QPushButton:hover{background:#20373f}')
        self.settings.clicked.connect(self.open_settings)

        panel=QFrame(self); panel.setGeometry(12,172,226,43)
        panel.setStyleSheet('QFrame{background:rgba(5,28,35,235);border:1px solid rgba(41,255,215,85);border-radius:27px}')
        h=QHBoxLayout(panel); h.setContentsMargins(8,2,6,2); h.setSpacing(5)
        h.addWidget(self.indicator)
        h.addWidget(self.status,1)
        h.addWidget(self.mic)
        h.addWidget(self.settings)

        self.confirm=QFrame(self); self.confirm.setGeometry(8,128,234,44); self.confirm.hide()
        self.confirm.setStyleSheet('QFrame{background:rgba(4,20,26,245);border:1px solid #48ffd0;border-radius:14px} QLabel{color:white} QPushButton{background:#48d6b0;color:#061217;border:0;border-radius:8px;padding:5px 9px}')
        ch=QHBoxLayout(self.confirm); ch.setContentsMargins(6,4,6,4)
        self.confirm_text=QLabel(''); self.confirm_text.setWordWrap(True); ch.addWidget(self.confirm_text,1)
        y=QPushButton('OK'); n=QPushButton('No'); y.clicked.connect(lambda:self.respond(True)); n.clicked.connect(lambda:self.respond(False)); ch.addWidget(y); ch.addWidget(n)

        self.move_to_corner(); self.show(); QTimer.singleShot(80,self.start_background_services)

    def move_to_corner(self):
        screen=QApplication.primaryScreen()
        if screen:
            geo=screen.availableGeometry(); self.move(geo.left()+12, geo.bottom()-self.height()-12)

    def toggle_listening(self):
        if self.assistant and not self.assistant.listening:
            self.assistant.manual_listen_once()
        elif self.assistant:
            self.assistant.listening=False
            self.handle_assistant_event('Say "Hey Luna AI"')

    def start_background_services(self):
        try:
            from minecraft_assist import MinecraftAssist
            self.minecraft_assist=MinecraftAssist(self.handle_assistant_event)
        except Exception as e:
            log_error('Minecraft Assist could not load.',e)
        threading.Thread(target=self._initialize_assistant,daemon=True).start()

    def _initialize_assistant(self):
        try:
            self.handle_assistant_event('Loading Luna Premium voice system…')
            from assistant import VoiceAssistant
            self.assistant=VoiceAssistant(self.handle_assistant_event)
            self.handle_assistant_event('Ready. Say "Hey Luna AI".')
            threading.Thread(target=self.loop,daemon=True).start()
        except Exception as e:
            log_error('Voice assistant failed to initialize.',e)
            self.handle_assistant_event(f'Voice system failed to start: {e}')

    def handle_assistant_event(self,msg): QTimer.singleShot(0,lambda m=msg:self._handle_assistant_event(m))
    def _handle_assistant_event(self,msg):
        if isinstance(msg,tuple) and msg and msg[0]=='CONFIRM':
            self.pending_action=msg[1]
            self.confirm_text.setText(str(msg[1]))
            self.confirm.show(); return
        if isinstance(msg,tuple) and msg and msg[0]=='MINECRAFT_RESPAWN_CONFIRM':
            self.pending_action={'type':'minecraft_respawn_assist'}
            self.confirm_text.setText(msg[1]); self.confirm.show(); return
        if msg=='MINECRAFT_ASSIST_START' and self.minecraft_assist: self.minecraft_assist.start(); return
        if msg=='MINECRAFT_ASSIST_STOP' and self.minecraft_assist: self.minecraft_assist.stop(); return
        text=str(msg); self.status.setText('Luna Founder\n'+text)
        low=text.lower()
        if 'listening' in low:
            self.status.setText("Luna Founder\nI'm listening")
            self.indicator.setStyleSheet('color:#59ffd2;background:transparent')
            self.canvas.set_expression('focused')
        elif 'ready' in low or 'standby' in low:
            self.status.setText('Luna Founder\nReady')
            self.indicator.setStyleSheet('color:#44ffc1;background:transparent')
            self.canvas.set_expression('happy')
        elif 'failed' in low or 'error' in low:
            self.status.setText('Luna Founder\nOops...')
            self.indicator.setStyleSheet('color:#ff7a8b;background:transparent')
            self.canvas.set_expression('sad')
        else:
            self.indicator.setStyleSheet('color:#60e8d0;background:transparent')

    def open_settings(self):
        try:
            from voice_apps import scan_apps, get_commands, set_command, remove_command
        except Exception as e:
            QMessageBox.warning(self,'Luna Founder',str(e)); return
        dlg=QDialog(self); dlg.setWindowTitle('Luna Premium — Settings — Luna Founder'); dlg.resize(520,470)
        dlg.setStyleSheet('QDialog{background:#09181d;color:white} QLabel{color:white} QLineEdit,QComboBox,QListWidget{background:#10262d;color:white;border:1px solid #25515a;border-radius:7px;padding:6px} QPushButton{background:#1e8f79;color:white;border:0;border-radius:8px;padding:8px 11px}')
        v=QVBoxLayout(dlg); v.addWidget(QLabel('Luna Premium'))
        v.addWidget(QLabel('Voice Activated Apps — assign a voice phrase to any detected app.'))
        apps=scan_apps(); combo=QComboBox(); combo.addItems([Path(p).stem for p in apps.values()]); v.addWidget(combo)
        phrase=QLineEdit(); phrase.setPlaceholderText('Example: open Spotify'); v.addWidget(phrase)
        row=QHBoxLayout(); save=QPushButton('Save Command'); rem=QPushButton('Remove Command'); row.addWidget(save); row.addWidget(rem); v.addLayout(row)
        listing=QListWidget(); v.addWidget(listing,1)
        close=QPushButton('Close'); close.clicked.connect(dlg.accept); v.addWidget(close)
        def refresh():
            listing.clear(); [listing.addItem(f'{p} → {Path(path).stem}') for p,path in sorted(get_commands().items())]
        def load(n):
            phrase.clear()
            for p,path in get_commands().items():
                if Path(path).stem.lower()==n.lower(): phrase.setText(p); break
        def save_cmd():
            try: set_command(combo.currentText(),phrase.text()); refresh(); QMessageBox.information(dlg,'Luna','Command saved.')
            except Exception as e: QMessageBox.warning(dlg,'Luna',str(e))
        def rem_cmd():
            if phrase.text().strip(): remove_command(phrase.text().strip()); refresh(); phrase.clear()
        combo.currentTextChanged.connect(load); save.clicked.connect(save_cmd); rem.clicked.connect(rem_cmd); refresh(); load(combo.currentText())

        # Premium Character Image
        char_box = QFrame(dlg)
        cbv = QVBoxLayout(char_box)
        cbv.setContentsMargins(0,8,0,4)
        cbv.addWidget(QLabel('Premium Character Image — choose an image from your PC. Luna will animate it with gentle idle motion.'))
        browse = QPushButton('Upload Character Image…')
        browse2 = QPushButton('Use Default Luna Image')
        animate = QCheckBox('Animate character image')
        animate.setChecked(self.canvas.anim_enabled)
        cbv.addWidget(browse); cbv.addWidget(browse2); cbv.addWidget(animate)
        v.insertWidget(v.count()-1, char_box)
        def choose_image():
            path,_ = QFileDialog.getOpenFileName(dlg,'Choose Luna Character Image',str(ROOT),'Images (*.png *.jpg *.jpeg *.webp *.bmp)')
            if path and self.canvas.set_image(path):
                self.canvas.image_path = Path(path)
                try:
                    dest = ROOT/'assets'/'premium_character.png'
                    QPixmap(path).save(str(dest), 'PNG')
                    self.canvas.set_image(dest)
                except Exception as e:
                    log_error('Could not save Premium Character Image.',e)
        browse.clicked.connect(choose_image)
        def default_image():
            self.canvas.anim_enabled=True
            self.canvas.set_image(ROOT/'assets'/'luna_v1.png')
        browse2.clicked.connect(default_image)
        animate.toggled.connect(lambda checked:setattr(self.canvas,'anim_enabled',bool(checked)))
        dlg.exec()

    def respond(self,yes):
        self.confirm.hide()
        if self.pending_action and self.pending_action.get('type')=='minecraft_respawn_assist':
            if yes and self.minecraft_assist: self.minecraft_assist.confirm_respawn()
        elif self.assistant: self.assistant.confirm_action(yes)
        self.pending_action=None

    def loop(self):
        while self.assistant and not self.assistant.stop_requested:
            try: self.assistant.run_once()
            except Exception as e:
                log_error('Voice loop error.',e); self.handle_assistant_event(f'ERROR: {e}'); break
    def closeEvent(self,e):
        try:
            if self.minecraft_assist: self.minecraft_assist.stop()
            if self.assistant: self.assistant.stop()
        except Exception as exc: log_error('Shutdown error.',exc)
        e.accept()

if __name__=='__main__':
    try:
        app=QApplication(sys.argv); app.setApplicationName('Luna'); app.setDesktopFileName('luna')
        icon=ROOT/'assets'/'luna.ico'
        if icon.exists(): app.setWindowIcon(QIcon(str(icon)))
        w=MainWindow(); w.show(); sys.exit(app.exec())
    except Exception as e:
        log_error('Fatal application startup error.',e); raise
