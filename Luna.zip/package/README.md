# Luna Premium — Version 2

Luna is a confirmation-gated Windows voice assistant. Say **"listen up"**, give a command, and Luna shows the exact action before doing it.

## Desktop, browser, and app control

Luna can launch common desktop apps (including Discord, Minecraft, Fortnite, Roblox, Chrome, Edge, and Notepad), open websites, search the web, type text, send hotkeys/keys, click or double-click screen coordinates, scroll, open folders, take screenshots, and run non-elevated PowerShell commands after confirmation.

These controls let Luna handle many ordinary browser and desktop workflows. Because browser pages and games change constantly, arbitrary website/game tasks may need a sequence of confirmed clicks/typing rather than a single command.

### Games
Luna can launch and perform ordinary UI actions where appropriate. It is **not intended to cheat, bot gameplay, exploit games, bypass anti-cheat, or evade game security**. Fortnite, Roblox, Minecraft servers, and other games may restrict automation.

## Installation

Use `installer.pyw` for the graphical installer. The installer keeps the base install smaller and offers speaker identification as an optional large download.

## Optional local AI

Set `OLLAMA_MODEL` in `.env` to let a local Ollama model turn more natural requests into Luna actions. Every resulting action still requires on-screen confirmation.


Screen analysis: say "Hey Luna AI" then "What's on my screen?". Screen capture and OCR are local.

TASKBAR PINNING
After installation, Luna creates a Start Menu shortcut named "Luna" and a desktop shortcut.
To pin Luna to the Windows taskbar: open Start, search for Luna, right-click Luna, then choose "Pin to taskbar".
Windows controls taskbar pinning, so Luna creates the proper app shortcut rather than silently changing your taskbar.


PLATFORM LAUNCHERS

Windows: double-click start.bat. It launches the Luna desktop app using the configured Windows environment.
Linux: run start_linux.sh. It creates/reuses the Linux virtual environment and launches the Luna desktop app.

Important: start.bat requires Command Prompt/batch execution to be permitted by Windows policy. If an administrator has disabled Command Prompt, this launcher cannot run on that PC.

STARTUP TROUBLESHOOTING
- Luna now displays its corner widget before loading the heavy voice/Whisper dependencies.
- The widget is positioned in the bottom-left corner on Windows and Linux.
- If the voice system fails, the widget remains visible and writes details to luna_startup.log.


PREMIUM UI UPDATE
The installed desktop app is branded Luna, uses the supplied Luna artwork, and includes a compact animated control panel in the bottom-left corner.

VOICE TYPING
Say "Hey Luna AI" then "start dictation". Luna types successive speech into the currently focused text box. Say "stop dictation" to stop.


PREMIUM CHARACTER IMAGE
Open Settings -> Premium Character Image to upload a PNG/JPG/WebP/BMP from your PC. Luna uses the image as her displayed character and applies gentle idle animation. This feature does not generate or alter sexual content; it only displays and animates an image you supply.


## VERSION 2
When a new Luna version is launched, its launcher searches for older Luna launcher/app processes, asks them to exit, and force-closes only those Luna processes that remain. Windows `start.bat`, Start Menu shortcuts, desktop shortcuts, and the installer all use the same launcher path.
