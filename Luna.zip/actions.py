import os
import subprocess
import webbrowser
from pathlib import Path

import pyautogui


class ActionError(Exception):
    pass


def _require_confirmation(action: dict):
    return action


def describe(action: dict) -> str:
    t = action.get("type")
    p = action.get("params", {})
    labels = {
        "open_app": f"Open application: {p.get('name')}",
        "open_app_path": f"Open application: {Path(p.get('path', "")).stem}",
        "open_url": f"Open website: {p.get('url')}",
        "search_web": f"Search the web for: {p.get('query')}",
        "type_text": f'Type: "{p.get("text", "")}"',
        "hotkey": f"Press hotkey: {'+'.join(p.get('keys', []))}",
        "press_key": f"Press key: {p.get('key')}",
        "click": f"Click at ({p.get('x')}, {p.get('y')})",
        "double_click": f"Double-click at ({p.get('x')}, {p.get('y')})",
        "scroll": f"Scroll {p.get('amount', 0)} clicks",
        "screenshot": f"Take screenshot: {p.get('path', 'screenshot.png')}",
        "shell": f'Run PowerShell command: {p.get("command")}',
        "open_folder": f"Open folder: {p.get('path')}",
        "create_folder": f"Create folder: {p.get('path')}",
        "delete_file": f"DELETE file: {p.get('path')}",
        "sleep_computer": "Put the computer to sleep",
        "analyze_screen": "Analyze what is currently on the screen",
    }
    return labels.get(t, f"Perform action: {t}")


def _launch_windows_app(name: str):
    """Launch common desktop apps, then fall back to Windows Start/shell resolution."""
    raw = name.strip()
    low = raw.lower()
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    program = Path(os.environ.get("ProgramFiles", ""))
    pf86 = Path(os.environ.get("ProgramFiles(x86)", ""))

    candidates = []
    if low in {"discord", "discord app"}:
        candidates += [
            local / "Discord" / "Update.exe",
        ]
        for p in [local / "Discord", local / "DiscordCanary", local / "DiscordPTB"]:
            if p.exists():
                exes = list(p.glob("app-*/Discord.exe"))
                candidates += exes[-3:]
    elif low in {"minecraft", "minecraft launcher"}:
        candidates += [
            local / "Programs" / "Minecraft Launcher" / "MinecraftLauncher.exe",
            program / "Minecraft Launcher" / "MinecraftLauncher.exe",
        ]
    elif low in {"roblox", "roblox player"}:
        candidates += [local / "Roblox" / "Versions"]
        versions = local / "Roblox" / "Versions"
        if versions.exists():
            candidates += list(versions.glob("*/RobloxPlayerBeta.exe"))[-5:]
    elif low in {"fortnite", "epic games", "epic games launcher"}:
        candidates += [
            program / "Epic Games" / "Launcher" / "Portal" / "Binaries" / "Win64" / "EpicGamesLauncher.exe",
            pf86 / "Epic Games" / "Launcher" / "Portal" / "Binaries" / "Win64" / "EpicGamesLauncher.exe",
        ]
    elif low in {"chrome", "google chrome"}:
        candidates += [
            program / "Google" / "Chrome" / "Application" / "chrome.exe",
            local / "Google" / "Chrome" / "Application" / "chrome.exe",
        ]
    elif low in {"edge", "microsoft edge"}:
        candidates += [program / "Microsoft" / "Edge" / "Application" / "msedge.exe"]
    elif low in {"notepad", "notepad.exe"}:
        candidates += [Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "notepad.exe"]

    for candidate in reversed(candidates):
        if not candidate:
            continue
        if candidate.is_file():
            if candidate.name.lower() == "update.exe" and low.startswith("discord"):
                subprocess.Popen([str(candidate), "--processStart", "Discord.exe"])
            else:
                subprocess.Popen([str(candidate)])
            return

    # Windows shell resolution supports many Start-menu registered desktop apps.
    subprocess.Popen(["cmd.exe", "/c", "start", "", raw], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def analyze_screen():
    """Capture the screen and read visible text locally with OCR."""
    try:
        image = pyautogui.screenshot()
    except Exception as exc:
        raise ActionError(f"Could not capture the screen: {exc}") from exc
    try:
        import pytesseract
        text = pytesseract.image_to_string(image).strip()
        return "I can see this on your screen:\n" + text if text else "I captured the screen, but I couldn't find readable text."
    except ImportError:
        return "I captured the screen, but local screen reading needs pytesseract and Tesseract OCR installed."
    except Exception as exc:
        return f"I captured the screen, but OCR failed: {exc}"


def execute(action: dict):
    t = action.get("type")
    p = action.get("params", {})
    no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    if t == "open_app_path":
        path = str(p["path"])
        if not os.path.exists(path):
            raise ActionError(f"Application path no longer exists: {path}")
        if os.name == "nt":
            os.startfile(path)
        else:
            subprocess.Popen([path])
        return f"Opened {Path(path).stem}."

    if t == "open_app":
        name = str(p["name"])
        _launch_windows_app(name)
        return f"Opened {name}."

    if t == "open_url":
        url = str(p["url"])
        if not (url.startswith("http://") or url.startswith("https://")):
            raise ActionError("Only http/https URLs are allowed.")
        webbrowser.open(url)
        return "Opened the website."

    if t == "search_web":
        from urllib.parse import quote_plus
        q = str(p.get("query", "")).strip()
        if not q:
            raise ActionError("Empty search query.")
        webbrowser.open("https://www.google.com/search?q=" + quote_plus(q))
        return "Opened a web search."

    if t == "type_text":
        text = str(p.get("text", ""))
        # Clipboard paste is much more reliable than pyautogui.write for Unicode.
        try:
            import pyperclip
            pyperclip.copy(text)
            pyautogui.hotkey("ctrl", "v")
        except Exception:
            pyautogui.write(text, interval=0.005)
        return "Typed the requested text."

    if t == "hotkey":
        keys = [str(k).lower() for k in p.get("keys", [])]
        if not keys or len(keys) > 8:
            raise ActionError("Invalid hotkey.")
        pyautogui.hotkey(*keys)
        return "Hotkey sent."

    if t == "press_key":
        key = str(p.get("key", "")).lower()
        allowed = set("abcdefghijklmnopqrstuvwxyz0123456789") | {
            "enter", "esc", "escape", "tab", "space", "backspace", "delete", "home", "end",
            "pageup", "pagedown", "up", "down", "left", "right", "shift", "ctrl", "alt", "win",
            "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12"
        }
        if key not in allowed:
            raise ActionError("Unsupported key.")
        pyautogui.press("esc" if key == "escape" else key)
        return f"Pressed {key}."

    if t in {"click", "double_click"}:
        try:
            x, y = int(p["x"]), int(p["y"])
        except Exception as exc:
            raise ActionError("Click coordinates must be integers.") from exc
        if x < 0 or y < 0:
            raise ActionError("Click coordinates cannot be negative.")
        if t == "click":
            pyautogui.click(x, y)
        else:
            pyautogui.doubleClick(x, y, interval=0.08)
        return "Mouse action completed."

    if t == "scroll":
        amount = int(p.get("amount", 0))
        if abs(amount) > 50:
            raise ActionError("Scroll amount is too large.")
        pyautogui.scroll(amount)
        return "Scrolled the window."

    if t == "screenshot":
        path = Path(p.get("path", "screenshot.png")).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        pyautogui.screenshot().save(path)
        return f"Screenshot saved to {path}."

    if t == "open_folder":
        path = Path(p["path"]).expanduser().resolve()
        if not path.exists() or not path.is_dir():
            raise ActionError(f"Folder does not exist: {path}")
        os.startfile(str(path))
        return "Opened the folder."

    if t == "create_folder":
        path = Path(p["path"]).expanduser().resolve()
        path.mkdir(parents=True, exist_ok=True)
        return f"Created {path}."

    if t == "analyze_screen":
        return analyze_screen()

    if t == "sleep_computer":
        try:
            subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0", "1", "0"], creationflags=no_window)
        except Exception as exc:
            raise ActionError(f"Could not put the computer to sleep: {exc}") from exc
        return "The computer is going to sleep."

    if t == "delete_file":
        path = Path(p["path"]).expanduser().resolve()
        if not path.exists() or not path.is_file():
            raise ActionError("The target is not an existing file.")
        path.unlink()
        return f"Deleted {path}."

    if t == "shell":
        command = str(p["command"]).strip()
        if not command:
            raise ActionError("Empty shell command.")
        completed = subprocess.run(
            ["powershell", "-NoProfile", "-Command", command],
            capture_output=True, text=True, timeout=120, creationflags=no_window
        )
        output = (completed.stdout or completed.stderr).strip()
        if len(output) > 3000:
            output = output[:3000] + "\n...[truncated]"
        if completed.returncode != 0:
            raise ActionError(output or f"PowerShell exited with {completed.returncode}.")
        return output or "Command completed."

    raise ActionError(f"Unknown action type: {t}")
