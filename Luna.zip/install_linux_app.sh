#!/usr/bin/env bash
set -e
BASE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.local/share/applications"
mkdir -p "$HOME/.local/share/luna"
# Copy once into the user's app directory. Future launches do not reinstall Luna.
cp -a "$BASE/." "$HOME/.local/share/luna/"
chmod +x "$HOME/.local/share/luna/start_linux.sh"
cat > "$HOME/.local/share/applications/luna.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Luna
Comment=Luna Version 1 Voice Assistant
Exec=$HOME/.local/share/luna/start_linux.sh
Path=$HOME/.local/share/luna
Terminal=false
StartupNotify=true
StartupWMClass=Luna
Icon=$HOME/.local/share/luna/assets/luna_v1.png
Categories=Utility;AudioVideo;
EOF
chmod 644 "$HOME/.local/share/applications/luna.desktop"
update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
echo "Luna is installed as a Linux app. You can launch it from your Applications menu and pin it to your dock/taskbar."
