# Luna Premium — $9.99

Publisher: Luna Founder
Wake phrase: **Hey Luna AI**

Includes the full code-drawn animated chibi Luna plus Premium desktop extensions.

Premium extensions include screen analysis, voice dictation, Voice Activated Apps, and Minecraft Assist.
