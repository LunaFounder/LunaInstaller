EDITION = 'premium'
DISPLAY_NAME = 'Luna Premium'
PRICE = '$9.99'
