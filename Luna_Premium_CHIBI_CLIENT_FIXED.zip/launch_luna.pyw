import os, subprocess, tkinter as tk
from tkinter import messagebox
from pathlib import Path

ROOT = Path(__file__).resolve().parent
try:
    CURRENT_VERSION = float((ROOT/'VERSION.txt').read_text(encoding='utf-8').strip())
except Exception:
    CURRENT_VERSION = 2.0

# Give Windows a stable app identity so Luna behaves as a normal taskbar app.
try:
    import ctypes
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Luna.Premium.VoiceAssistant')
except Exception:
    pass

name='.venv'
marker=ROOT/'luna_environment.txt'
if marker.exists():
    try: name=marker.read_text(encoding='utf-8').strip() or name
    except Exception: pass
ENV=ROOT/name
PYW=ENV/'Scripts'/'pythonw.exe'
PY=ENV/'Scripts'/'python.exe'
APP=ROOT/'app.py'
exe=PYW if PYW.exists() else PY

if not exe.exists():
    r=tk.Tk(); r.withdraw()
    messagebox.showerror('Luna', 'Luna is not installed yet. Run the Luna installer first.')
    r.destroy(); raise SystemExit(1)

def process_version(proc):
    try:
        text=' '.join(proc.info.get('cmdline') or []).lower()
        if 'luna' not in text:
            return None
        candidate=None
        for item in proc.info.get('cmdline') or []:
            p=Path(str(item).strip('"'))
            if p.name.lower() in ('launch_luna.pyw','app.py'):
                candidate=p.parent; break
        if candidate is None: return None
        vf=candidate/'VERSION.txt'
        return float(vf.read_text(encoding='utf-8').strip()) if vf.exists() else 1.0
    except Exception:
        return None

def close_older():
    try:
        import psutil
        me=os.getpid(); old=[]
        for proc in psutil.process_iter(['pid','cmdline']):
            if proc.info['pid']==me: continue
            try:
                v=process_version(proc)
                if v is not None and v < CURRENT_VERSION: old.append(proc)
            except Exception: pass
        for p in old:
            try: p.terminate()
            except Exception: pass
        if old:
            _,alive=psutil.wait_procs(old, timeout=2)
            for p in alive:
                try:p.kill()
                except Exception:pass
    except Exception:
        pass

close_older()
subprocess.Popen([str(exe), str(APP)], cwd=str(ROOT), creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
