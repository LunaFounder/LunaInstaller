$ErrorActionPreference = 'SilentlyContinue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Luna'
New-Item -ItemType Directory -Force -Path $startMenu | Out-Null
$shortcutPath = Join-Path $startMenu 'Luna.lnk'
$target = Join-Path $root 'launch_luna.pyw'
$working = $root
$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut($shortcutPath)
$sc.TargetPath = $target
$sc.WorkingDirectory = $working
$sc.Description = 'Luna Premium — Voice AI Assistant'
$sc.AppUserModelId = 'Luna.VoiceAssistant.Premium'
$icon = Join-Path $root 'assets\luna.ico'
if (Test-Path $icon) { $sc.IconLocation = "$icon,0" }
$sc.Save()

# Also create a desktop shortcut for easy first launch.
$desktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Luna.lnk'
$sc2 = $wsh.CreateShortcut($desktopShortcut)
$sc2.TargetPath = $target
$sc2.WorkingDirectory = $working
$sc2.Description = 'Luna Premium — Voice AI Assistant'
$sc2.AppUserModelId = 'Luna.VoiceAssistant.Premium'
if (Test-Path $icon) { $sc2.IconLocation = "$icon,0" }
$sc2.Save()

Write-Host "Luna shortcut created at: $shortcutPath"
Write-Host "You can now right-click Luna from Start and choose 'Pin to taskbar'."
