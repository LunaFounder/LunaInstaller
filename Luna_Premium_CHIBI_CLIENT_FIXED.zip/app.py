import sys, threading, math, os, traceback
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QRectF, QPropertyAnimation, QEasingCurve, QPointF
from PySide6.QtGui import QColor, QPainter, QFont, QPixmap, QIcon, QPainterPath
from edition import EDITION, DISPLAY_NAME, PRICE
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QHBoxLayout, QVBoxLayout, QFrame, QDialog, QComboBox, QLineEdit, QListWidget, QMessageBox, QFileDialog, QCheckBox

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
STARTUP_LOG = ROOT / 'luna_startup.log'

def log_error(prefix, exc=None):
    try:
        with STARTUP_LOG.open('a', encoding='utf-8') as f:
            f.write('\n' + '='*70 + '\n' + prefix + '\n')
            if exc: f.write(''.join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
    except Exception:
        pass

class LunaVisual(QWidget):
    """Image-based animated chibi Luna. Uses the bundled Luna artwork instead of particles."""
    def __init__(self):
        super().__init__()
        self.phase = 0.0
        self.state = 'idle'
        self.expression = 'neutral'
        self.setFixedSize(240, 188)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.pixmap = QPixmap(str(ROOT / 'assets' / 'luna_v2_cute.png'))
        if self.pixmap.isNull():
            self.pixmap = QPixmap(str(ROOT / 'assets' / 'luna_v1.png'))
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(33)

    def set_state(self, state):
        state = str(state).lower().strip()
        if state not in {'idle', 'listening', 'speaking', 'processing', 'error', 'confirm'}:
            state = 'idle'
        self.state = state
        self.expression = {
            'idle': 'neutral', 'listening': 'focused', 'speaking': 'happy',
            'processing': 'focused', 'error': 'sad', 'confirm': 'surprised'
        }[state]
        self.update()

    def set_expression(self, expression):
        self.expression = str(expression).lower().strip()
        self.update()

    def tick(self):
        self.phase += 0.13
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)

        if self.pixmap.isNull():
            p.setPen(QColor(255, 255, 255, 220))
            p.drawText(self.rect(), Qt.AlignCenter, 'Luna')
            return

        # Gentle VTuber-like idle motion: bob and tiny sway, with stronger movement while speaking.
        bob = math.sin(self.phase * 1.7) * (2.2 if self.state == 'idle' else 2.8)
        sway = math.sin(self.phase * 0.9) * 1.6
        if self.state == 'speaking':
            bob += math.sin(self.phase * 5.8) * 1.2
        scale = 0.94 + 0.018 * math.sin(self.phase * 1.3)

        target_h = int(self.height() * 1.02 * scale)
        target_w = int(self.pixmap.width() * (target_h / self.pixmap.height()))
        scaled = self.pixmap.scaled(target_w, target_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        x = int((self.width() - scaled.width()) / 2 + sway)
        y = int((self.height() - scaled.height()) / 2 + bob - 4)

        # Soft state glow behind Luna; no floating particle dots.
        glow = {
            'idle': QColor(144, 111, 255, 30),
            'listening': QColor(74, 230, 255, 55),
            'speaking': QColor(255, 120, 210, 48),
            'processing': QColor(100, 180, 255, 42),
            'error': QColor(255, 90, 120, 44),
            'confirm': QColor(255, 215, 100, 46),
        }.get(self.state, QColor(144, 111, 255, 30))
        p.setPen(Qt.NoPen)
        p.setBrush(glow)
        r = 70 + int(3 * math.sin(self.phase * 2.0))
        p.drawEllipse(QRectF(self.width()/2-r, 70-r*0.72, r*2, r*1.45))

        p.drawPixmap(x, y, scaled)

        # Small animated state ring beneath/around the character only when active.
        if self.state in {'listening', 'speaking', 'processing'}:
            alpha = 75 + int(55 * (math.sin(self.phase * 4.0) + 1) / 2)
            ring = QColor(170, 140, 255, alpha) if self.state != 'listening' else QColor(74, 240, 225, alpha)
            pen = p.pen()
            pen.setColor(ring)
            pen.setWidthF(2.0)
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QRectF(50, 151, 140, 28))

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f'{DISPLAY_NAME} — Luna Founder')
        icon=ROOT/'assets'/'luna.ico'
        if icon.exists(): self.setWindowIcon(QIcon(str(icon)))
        flags=Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(240,220)
        self.pending_action=None; self.assistant=None; self.minecraft_assist=None

        self.canvas=LunaVisual()
        self.canvas.setParent(self)

        self.status=QLabel(f'Luna Founder\n{DISPLAY_NAME.replace("Luna ", "")} Ready')
        self.status.setFont(QFont('Segoe UI', 8, QFont.Bold)); self.status.setStyleSheet('color:white;background:transparent')
        self.status.setFixedHeight(32)
        self.indicator=QLabel('●')
        self.indicator.setFont(QFont('Segoe UI', 12, QFont.Bold)); self.indicator.setStyleSheet('color:#44ffc1;background:transparent')

        self.mic=QPushButton('🎙'); self.mic.setFixedSize(32,32)
        self.mic.setStyleSheet('QPushButton{background:#0d9d82;color:white;border:0;border-radius:14px;font-size:12px} QPushButton:hover{background:#12b694}')
        self.mic.clicked.connect(self.toggle_listening)
        self.settings=QPushButton('⚙'); self.settings.setFixedSize(28,28)
        self.settings.setStyleSheet('QPushButton{background:#17252b;color:#d8ffff;border:1px solid #24444d;border-radius:16px;font-size:14px} QPushButton:hover{background:#20373f}')
        self.settings.clicked.connect(self.open_settings)

        panel=QFrame(self); panel.setGeometry(8,178,224,36)
        panel.setStyleSheet('QFrame{background:rgba(5,28,35,235);border:1px solid rgba(41,255,215,85);border-radius:27px}')
        h=QHBoxLayout(panel); h.setContentsMargins(6,1,5,1); h.setSpacing(4)
        h.addWidget(self.indicator)
        h.addWidget(self.status,1)
        h.addWidget(self.mic)
        h.addWidget(self.settings)

        self.confirm=QFrame(self); self.confirm.setGeometry(8,128,234,44); self.confirm.hide()
        self.confirm.setStyleSheet('QFrame{background:rgba(4,20,26,245);border:1px solid #48ffd0;border-radius:14px} QLabel{color:white} QPushButton{background:#48d6b0;color:#061217;border:0;border-radius:8px;padding:5px 9px}')
        ch=QHBoxLayout(self.confirm); ch.setContentsMargins(6,4,6,4)
        self.confirm_text=QLabel(''); self.confirm_text.setWordWrap(True); ch.addWidget(self.confirm_text,1)
        y=QPushButton('OK'); n=QPushButton('No'); y.clicked.connect(lambda:self.respond(True)); n.clicked.connect(lambda:self.respond(False)); ch.addWidget(y); ch.addWidget(n)

        self.move_to_corner(); self.show(); QTimer.singleShot(80,self.start_background_services)

    def move_to_corner(self):
        screen=QApplication.primaryScreen()
        if screen:
            geo=screen.availableGeometry(); self.move(geo.left()+12, geo.bottom()-self.height()-12)

    def toggle_listening(self):
        if self.assistant and not self.assistant.listening:
            self.assistant.manual_listen_once()
        elif self.assistant:
            self.assistant.listening=False
            self.handle_assistant_event('Say "Hey Luna AI"')

    def start_background_services(self):
        try:
            from minecraft_assist import MinecraftAssist
            self.minecraft_assist=MinecraftAssist(self.handle_assistant_event)
        except Exception as e:
            log_error('Minecraft Assist could not load.',e)
        threading.Thread(target=self._initialize_assistant,daemon=True).start()

    def _initialize_assistant(self):
        try:
            self.handle_assistant_event('Loading Luna Premium voice system…')
            from assistant import VoiceAssistant
            self.assistant=VoiceAssistant(self.handle_assistant_event)
            self.handle_assistant_event('Ready. Say "Hey Luna AI".')
            threading.Thread(target=self.loop,daemon=True).start()
        except Exception as e:
            log_error('Voice assistant failed to initialize.',e)
            self.handle_assistant_event(f'Voice system failed to start: {e}')

    def handle_assistant_event(self,msg): QTimer.singleShot(0,lambda m=msg:self._handle_assistant_event(m))
    def _handle_assistant_event(self,msg):
        if isinstance(msg,tuple) and msg and msg[0]=='CONFIRM':
            self.pending_action=msg[1]
            self.confirm_text.setText(str(msg[1]))
            self.confirm.show()
            self.canvas.set_state('confirm')
            return
        if isinstance(msg,tuple) and msg and msg[0]=='MINECRAFT_RESPAWN_CONFIRM':
            self.pending_action={'type':'minecraft_respawn_assist'}
            self.confirm_text.setText(msg[1]); self.confirm.show(); self.canvas.set_state('confirm'); return
        if msg=='MINECRAFT_ASSIST_START' and self.minecraft_assist: self.minecraft_assist.start(); return
        if msg=='MINECRAFT_ASSIST_STOP' and self.minecraft_assist: self.minecraft_assist.stop(); return
        text=str(msg); self.status.setText('Luna Founder\n'+text)
        low=text.lower()
        if 'speaking' in low:
            self.status.setText('Luna Founder\nSpeaking')
            self.indicator.setStyleSheet('color:#b59cff;background:transparent')
            self.canvas.set_state('speaking')
        elif 'thinking' in low or 'processing' in low:
            self.status.setText('Luna Founder\nThinking…')
            self.indicator.setStyleSheet('color:#6fd6ff;background:transparent')
            self.canvas.set_state('processing')
        elif low.startswith('command:'):
            self.status.setText('Luna Founder\nThinking…')
            self.indicator.setStyleSheet('color:#6fd6ff;background:transparent')
            self.canvas.set_state('processing')
        elif 'listening' in low:
            self.status.setText("Luna Founder\nI'm listening")
            self.indicator.setStyleSheet('color:#59ffd2;background:transparent')
            self.canvas.set_state('listening')
        elif 'ready' in low or 'standby' in low:
            self.status.setText('Luna Founder\nReady')
            self.indicator.setStyleSheet('color:#44ffc1;background:transparent')
            self.canvas.set_state('idle')
        elif 'failed' in low or 'error' in low:
            self.status.setText('Luna Founder\nOops...')
            self.indicator.setStyleSheet('color:#ff7a8b;background:transparent')
            self.canvas.set_state('error')
        else:
            self.indicator.setStyleSheet('color:#60e8d0;background:transparent')

    def open_settings(self):
        try:
            from voice_apps import scan_apps, get_commands, set_command, remove_command
        except Exception as e:
            QMessageBox.warning(self,'Luna Founder',str(e)); return
        dlg=QDialog(self); dlg.setWindowTitle('Luna Premium — Settings — Luna Founder'); dlg.resize(520,470)
        dlg.setStyleSheet('QDialog{background:#09181d;color:white} QLabel{color:white} QLineEdit,QComboBox,QListWidget{background:#10262d;color:white;border:1px solid #25515a;border-radius:7px;padding:6px} QPushButton{background:#1e8f79;color:white;border:0;border-radius:8px;padding:8px 11px}')
        v=QVBoxLayout(dlg); v.addWidget(QLabel('Luna Premium'))
        v.addWidget(QLabel('Voice Activated Apps — assign a voice phrase to any detected app.'))
        apps=scan_apps(); combo=QComboBox(); combo.addItems([Path(p).stem for p in apps.values()]); v.addWidget(combo)
        phrase=QLineEdit(); phrase.setPlaceholderText('Example: open Spotify'); v.addWidget(phrase)
        row=QHBoxLayout(); save=QPushButton('Save Command'); rem=QPushButton('Remove Command'); row.addWidget(save); row.addWidget(rem); v.addLayout(row)
        listing=QListWidget(); v.addWidget(listing,1)
        close=QPushButton('Close'); close.clicked.connect(dlg.accept); v.addWidget(close)
        def refresh():
            listing.clear(); [listing.addItem(f'{p} → {Path(path).stem}') for p,path in sorted(get_commands().items())]
        def load(n):
            phrase.clear()
            for p,path in get_commands().items():
                if Path(path).stem.lower()==n.lower(): phrase.setText(p); break
        def save_cmd():
            try: set_command(combo.currentText(),phrase.text()); refresh(); QMessageBox.information(dlg,'Luna','Command saved.')
            except Exception as e: QMessageBox.warning(dlg,'Luna',str(e))
        def rem_cmd():
            if phrase.text().strip(): remove_command(phrase.text().strip()); refresh(); phrase.clear()
        combo.currentTextChanged.connect(load); save.clicked.connect(save_cmd); rem.clicked.connect(rem_cmd); refresh(); load(combo.currentText())

        # Code-drawn chibi character — no image asset is required.
        char_box = QFrame(dlg)
        cbv = QVBoxLayout(char_box)
        cbv.setContentsMargins(0,8,0,4)
        cbv.addWidget(QLabel('Chibi Character — fully code-drawn and animated by Luna.'))
        cbv.addWidget(QLabel('States: standby, listening, speaking, thinking, confirmation, and error.'))
        v.insertWidget(v.count()-1, char_box)

        dlg.exec()

    def respond(self,yes):
        self.confirm.hide()
        self.canvas.set_state('processing')
        if self.pending_action and self.pending_action.get('type')=='minecraft_respawn_assist':
            if yes and self.minecraft_assist: self.minecraft_assist.confirm_respawn()
        elif self.assistant: self.assistant.confirm_action(yes)
        self.pending_action=None

    def loop(self):
        while self.assistant and not self.assistant.stop_requested:
            try: self.assistant.run_once()
            except Exception as e:
                log_error('Voice loop error.',e); self.handle_assistant_event(f'ERROR: {e}'); break
    def closeEvent(self,e):
        try:
            if self.minecraft_assist: self.minecraft_assist.stop()
            if self.assistant: self.assistant.stop()
        except Exception as exc: log_error('Shutdown error.',exc)
        e.accept()

if __name__=='__main__':
    try:
        app=QApplication(sys.argv); app.setApplicationName('Luna'); app.setDesktopFileName('luna')
        icon=ROOT/'assets'/'luna.ico'
        if icon.exists(): app.setWindowIcon(QIcon(str(icon)))
        w=MainWindow(); w.show(); sys.exit(app.exec())
    except Exception as e:
        log_error('Fatal application startup error.',e); raise
