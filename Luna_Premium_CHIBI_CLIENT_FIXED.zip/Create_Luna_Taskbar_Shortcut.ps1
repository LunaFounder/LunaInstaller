$ErrorActionPreference='SilentlyContinue'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$wscript="$env:WINDIR\System32\wscript.exe"
$vbs=Join-Path $root 'Luna_Taskbar.vbs'
$icon=Join-Path $root 'assets\luna.ico'
$wsh=New-Object -ComObject WScript.Shell
$startMenu=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Luna'
New-Item -ItemType Directory -Force -Path $startMenu | Out-Null
foreach($path in @((Join-Path $startMenu 'Luna.lnk'),(Join-Path ([Environment]::GetFolderPath('Desktop')) 'Luna.lnk'))){
  $sc=$wsh.CreateShortcut($path)
  $sc.TargetPath=$wscript
  $sc.Arguments=('"'+$vbs+'"')
  $sc.WorkingDirectory=$root
  $sc.Description='Luna Premium'
  if(Test-Path $icon){$sc.IconLocation="$icon,0"}
  $sc.Save()
}
