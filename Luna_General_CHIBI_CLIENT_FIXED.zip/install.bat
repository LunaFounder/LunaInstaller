@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "EDITION=General"
set "TARGET=%LOCALAPPDATA%\Luna\%EDITION%"
set "VENV=%TARGET%\venv"
echo ==========================================
echo        Luna %EDITION% Installer
echo ==========================================
echo.
if not exist "%TARGET%" mkdir "%TARGET%"
echo Copying Luna files...
xcopy "%~dp0*" "%TARGET%\" /E /I /Y /H >nul
if errorlevel 1 (
  echo ERROR: Could not copy Luna files.
  pause
  exit /b 1
)
set "PY=py"
where py >nul 2>&1
if errorlevel 1 set "PY=python"
%PY% --version >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python is not installed or not on PATH.
  echo Install Python 3.11+ and run install.bat again.
  pause
  exit /b 1
)
if not exist "%VENV%\Scripts\python.exe" (
  echo Creating Luna Python environment...
  %PY% -m venv "%VENV%"
  if errorlevel 1 (
    echo ERROR: Could not create Python environment.
    pause
    exit /b 1
  )
)
echo Installing required Luna packages...
"%VENV%\Scripts\python.exe" -m pip install --upgrade pip
if exist "%TARGET%\requirements.txt" (
  "%VENV%\Scripts\python.exe" -m pip install -r "%TARGET%\requirements.txt"
) else (
  "%VENV%\Scripts\python.exe" -m pip install PySide6
)
if errorlevel 1 (
  echo ERROR: Dependency installation failed.
  pause
  exit /b 1
)
if exist "%TARGET%\app.py" (
  set "ENTRY=app.py"
) else if exist "%TARGET%\main.py" (
  set "ENTRY=main.py"
) else if exist "%TARGET%\luna.py" (
  set "ENTRY=luna.py"
) else (
  echo ERROR: Luna app.py/main.py/luna.py was not found.
  pause
  exit /b 1
)
(
  echo @echo off
  echo setlocal
  echo cd /d "%%~dp0"
  echo "%%~dp0venv\Scripts\python.exe" "%%~dp0!ENTRY!"
  echo if errorlevel 1 pause
) > "%TARGET%\start.bat"

echo.
echo Installation finished. Starting Luna...
start "" "%TARGET%\start.bat"
exit /b 0
