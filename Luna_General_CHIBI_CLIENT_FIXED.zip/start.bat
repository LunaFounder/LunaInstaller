@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Luna
if exist ".venv\Scripts\pythonw.exe" (
  start "Luna" /b ".venv\Scripts\pythonw.exe" "%~dp0launch_luna.pyw"
  exit /b 0
)
echo Luna is not installed in this folder yet.
echo Run install.bat first.
pause
