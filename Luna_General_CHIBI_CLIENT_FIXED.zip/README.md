# Luna General — Free

Publisher: Luna Founder
Wake phrase: **Hey Luna AI**

Luna General is the free edition with the core voice assistant and the 100% code-drawn animated chibi character.

Included:
- Hey Luna AI wake phrase
- Voice commands
- Web search
- App launching
- Typing and keyboard controls
- Screenshot command
- Animated standby, listening, thinking, speaking, confirmation, and error states

Premium-only extensions intentionally omitted from this edition:
- Screen analysis
- Voice dictation
- Voice Activated Apps
- Minecraft Assist
