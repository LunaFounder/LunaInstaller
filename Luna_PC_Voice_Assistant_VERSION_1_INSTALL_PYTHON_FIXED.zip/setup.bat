@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>&1
if not errorlevel 1 goto launch_installer

where python >nul 2>&1
if not errorlevel 1 (
  for /f "delims=" %%P in ('where python') do (
    echo %%P | findstr /I "WindowsApps" >nul
    if errorlevel 1 goto launch_installer
  )
)

echo.
echo Luna needs Python 3.11 or newer to install.
echo The Windows Store Python alias was detected or Python is missing.
echo.
echo Opening the official Python download page once...
start "" "https://www.python.org/downloads/windows/"
echo.
echo Install Python 3.11+ and make sure the Python Launcher is installed.
echo Then run setup.bat again.
pause
exit /b 1

:launch_installer
start "Luna Installer" "%~dp0installer.pyw"
exit /b 0
