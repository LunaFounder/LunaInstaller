from pathlib import Path
import os, sys, traceback

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

try:
    import app
    if hasattr(app, 'main'):
        app.main()
    else:
        raise RuntimeError('app.py does not expose main()')
except Exception:
    (ROOT / 'luna_python_startup.log').write_text(traceback.format_exc(), encoding='utf-8')
    raise
