EDITION = 'general'
DISPLAY_NAME = 'Luna General'
PRICE = 'Free'
