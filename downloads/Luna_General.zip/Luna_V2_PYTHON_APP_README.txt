Luna V2 Python App

This package is a Python-first launcher for the Luna desktop application.

Windows:
1. Make sure Python is installed.
2. Install Luna's requirements if they are not already installed.
3. Double-click Luna.pyw.
4. Luna should open as a desktop GUI without a console window.

Linux:
Use your normal Python environment and run Luna.py, or keep using start_linux.sh.

If Luna fails to open, check luna_python_startup.log in this folder.


TASKBAR: Use the Start Menu Luna shortcut and choose Pin to taskbar.
