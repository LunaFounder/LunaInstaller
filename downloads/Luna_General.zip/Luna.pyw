import os
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

try:
    from app import main
except Exception:
    # Fall back to the app module's usual entry point if no main() exists.
    try:
        import app
        if hasattr(app, 'main'):
            app.main()
        else:
            raise
    except Exception:
        (ROOT / 'luna_python_startup.log').write_text(
            traceback.format_exc(), encoding='utf-8'
        )
        raise
else:
    main()
