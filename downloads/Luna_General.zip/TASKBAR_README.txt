LUNA TASKBAR SETUP

1. Install Luna normally first.
2. If the installer does not create the shortcut, right-click Start.bat and run the included PowerShell shortcut script if your PC allows it.
3. The script creates a Start Menu shortcut named Luna and a desktop shortcut.
4. Open Start, search for Luna, right-click Luna, and choose Pin to taskbar.
5. Clicking the pinned Luna icon launches the app directly through a hidden Windows Script Host process; no Command Prompt window is opened.

The actual Luna GUI requests a stable Windows AppUserModelID so Windows groups it as Luna instead of Python.
