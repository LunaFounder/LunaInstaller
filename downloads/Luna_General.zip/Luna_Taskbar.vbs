Option Explicit
Dim fso, sh, root, marker, envName, env, pyw, app, cmd, q
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
marker = fso.BuildPath(root, "luna_environment.txt")
envName = ".venv"
If fso.FileExists(marker) Then
  envName = Trim(fso.OpenTextFile(marker, 1).ReadAll)
  If envName = "" Then envName = ".venv"
End If
env = fso.BuildPath(root, envName)
pyw = fso.BuildPath(env, "Scripts\pythonw.exe")
app = fso.BuildPath(root, "launch_luna.pyw")
If Not fso.FileExists(pyw) Then
  MsgBox "Luna is not installed yet. Please run the Luna installer first.", 48, "Luna"
  WScript.Quit 1
End If
q = Chr(34)
cmd = q & pyw & q & " " & q & app & q
sh.Run cmd, 0, False
