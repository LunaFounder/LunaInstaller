import json
import os
import re
import tempfile
import threading
import time
from pathlib import Path

import numpy as np
import sounddevice as sd
import soundfile as sf
import pyttsx3
import requests
from dotenv import load_dotenv
from faster_whisper import WhisperModel

from actions import describe, execute, ActionError
from edition import EDITION, DISPLAY_NAME

load_dotenv()


class VoiceAssistant:
    def __init__(self, event_cb=None):
        self.event_cb = event_cb or (lambda *_: None)
        self.whisper = WhisperModel(
            os.getenv("WHISPER_MODEL", "small.en"),
            device="cpu",
            compute_type="int8"
        )

        self.engine = pyttsx3.init()
        self._select_female_voice()
        self.profiles = self._load_profiles()
        self.current_speaker = "default"
        self.listening = False
        self.dictation_mode = False
        self.stop_requested = False

    def _load_profiles(self):
        try:
            return json.loads(Path("profiles.json").read_text(encoding="utf-8"))
        except Exception:
            return {"default": {"name": "Guest", "style": "friendly, concise"}}

    def _select_female_voice(self):
        """Prefer a female English system voice when one is available."""
        try:
            voices = self.engine.getProperty("voices") or []
            preferred = []
            for voice in voices:
                blob = " ".join(str(getattr(voice, a, "")) for a in ("name", "id", "gender", "languages")).lower()
                if any(k in blob for k in ("female", "zira", "samantha", "victoria", "karen", "susan", "amy", "libby", "hazel", "english-us+f3", "en-us+f3")):
                    preferred.append(voice)
            if not preferred:
                preferred = [v for v in voices if "english" in " ".join(str(getattr(v,a,"")) for a in ("name","id","languages")).lower()]
            if preferred:
                self.engine.setProperty("voice", preferred[0].id)
        except Exception:
            pass

    def _say(self, text):
        profile = self.profiles.get(self.current_speaker, self.profiles["default"])
        self.engine.setProperty("rate", profile.get("voice_rate", 185))
        self.engine.setProperty("volume", profile.get("voice_volume", 1.0))
        try:
            self.event_cb("Speaking…")
        except Exception:
            pass
        self.engine.say(text)
        self.engine.runAndWait()
        try:
            self.event_cb("Ready.")
        except Exception:
            pass

    def record(self, seconds=5):
        try:
            audio = sd.rec(int(seconds * 16000), samplerate=16000, channels=1, dtype="float32")
            sd.wait()
            if audio is None or len(audio) == 0:
                raise RuntimeError("No microphone audio was captured.")
            return audio
        except Exception as e:
            self.event_cb(f"Microphone error: {e}")
            raise

    def transcribe(self, audio):
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            path = f.name
        sf.write(path, audio, 16000)
        try:
            segments, _ = self.whisper.transcribe(
                path,
                language="en",
                vad_filter=True,
                beam_size=2,
                initial_prompt="Hey Luna AI, open, start, launch, search, type, what is on my screen"
            )
            return " ".join(seg.text.strip() for seg in segments).strip(), path
        except Exception:
            os.unlink(path)
            raise

    def listen_for_wake(self):
        self.event_cb('Say "Hey Luna AI"')
        while not self.stop_requested:
            audio = self.record(3)
            text, path = self.transcribe(audio)
            try:
                low = re.sub(r"[^a-z ]", " ", text.lower())
                low = re.sub(r"\s+", " ", low).strip()
                # Accept the new wake phrase plus natural Whisper variants.
                wake_ok = (
                    bool(re.search(r"\bhey\s+luna\s+ai\b", low))
                    or bool(re.search(r"\bhey\s+luna\b", low))
                    or bool(re.search(r"\b(hey|hay|heya)\s+(luna|lena|lunaah)(?:\s+(ai|a\s*i|eye))?\b", low))
                )
                if wake_ok:
                    self.current_speaker = "default"
                    return True
            finally:
                try: os.unlink(path)
                except OSError: pass
        return False

    def capture_command(self):
        self.event_cb("I'm listening.")
        audio = self.record(7)
        text, path = self.transcribe(audio)
        # Strip an accidental repeated wake phrase from the command transcript.
        clean = re.sub(r"^\s*(?:hey|hay|heya)\s+l(?:una|ena)(?:\s+(?:ai|a\s*i|eye))?\s*[,;:.-]?\s*", "", text, flags=re.I)
        return clean.strip(), path

    def parse_command(self, text):
        low = text.lower().strip()

        # General edition intentionally keeps the core voice assistant free.
        # Premium-only desktop extensions are disabled here.
        premium_only_phrases = (
            'start dictation', 'stop dictation', 'typing mode', 'dictation mode',
            "what's on my screen", 'what is on my screen', 'analyze my screen',
            'read my screen', 'scan my screen', 'voice activated apps', 'assign a voice command'
        )
        if any(phrase in low for phrase in premium_only_phrases):
            return {"type": "general_unavailable", "params": {}}

        # Voice Activated Apps is a Premium-only extension.

        # Common app shortcuts. These are still confirmation-gated by the UI.
        aliases = {
            "discord": "Discord", "minecraft": "Minecraft", "minecraft launcher": "Minecraft Launcher",
            "fortnite": "Fortnite", "roblox": "Roblox", "chrome": "Chrome",
            "google chrome": "Google Chrome", "edge": "Microsoft Edge", "notepad": "Notepad"
        }

        # Luna's official Discord server shortcut. Any natural request for the
        # Discord server opens the fixed invite link instead of the Discord app.
        discord_server_patterns = (
            r"\bdiscord\s+server\b",
            r"\bserver\s+discord\b",
            r"\bdiscord\s+invite\b",
            r"\bdiscord\s+link\b",
        )
        if any(re.search(pattern, low) for pattern in discord_server_patterns):
            return {"type": "open_url", "params": {"url": "https://discord.gg/PUHaFEnf6r"}}

        m = re.match(r"(?:open|launch|start)\s+(.+)", text, re.I)
        if m:
            target = m.group(1).strip()
            if re.match(r"https?://", target):
                return {"type": "open_url", "params": {"url": target}}
            return {"type": "open_app", "params": {"name": aliases.get(target.lower(), target)}}

        m = re.match(r"(?:search(?: the)? web(?: for)?|google|search)\s+(.+)", text, re.I)
        if m:
            return {"type": "search_web", "params": {"query": m.group(1).strip()}}

        m = re.match(r"(?:go to|open website)\s+(.+)", text, re.I)
        if m:
            target = m.group(1).strip()
            if "." not in target:
                target = "https://www.google.com/search?q=" + requests.utils.quote(target)
            elif not target.startswith("http"):
                target = "https://" + target
            return {"type": "open_url", "params": {"url": target}}

        if low in {"start dictation", "start typing mode", "typing mode on", "dictation mode on"}:
            return {"type":"dictation_start", "params":{}}
        if low in {"stop dictation", "stop typing mode", "typing mode off", "dictation mode off"}:
            return {"type":"dictation_stop", "params":{}}

        m = re.match(r"type\s+(.+)", text, re.I)
        if m:
            return {"type": "type_text", "params": {"text": m.group(1)}}

        m = re.match(r"(?:press|hotkey)\s+(.+)", text, re.I)
        if m:
            key_aliases = {"control": "ctrl", "escape": "esc", "windows": "win", "command": "win", "return": "enter"}
            keys = [key_aliases.get(x.lower(), x.lower()) for x in re.split(r"[\s,+]+", m.group(1)) if x]
            return {"type": "hotkey", "params": {"keys": keys}}

        m = re.match(r"(?:press|hit)\s+(?:the\s+)?(.+)", text, re.I)
        if m:
            return {"type": "press_key", "params": {"key": m.group(1).strip().lower()}}

        m = re.match(r"(?:click|tap)\s+(?:at\s+)?(\d+)\s*[, ]\s*(\d+)", text, re.I)
        if m:
            return {"type": "click", "params": {"x": int(m.group(1)), "y": int(m.group(2))}}

        m = re.match(r"double\s+click\s+(?:at\s+)?(\d+)\s*[, ]\s*(\d+)", text, re.I)
        if m:
            return {"type": "double_click", "params": {"x": int(m.group(1)), "y": int(m.group(2))}}

        m = re.match(r"scroll\s+(up|down)(?:\s+(\d+))?", text, re.I)
        if m:
            amount = int(m.group(2) or 5) * (1 if m.group(1).lower() == "up" else -1)
            return {"type": "scroll", "params": {"amount": amount}}

        if "screenshot" in low:
            return {"type": "screenshot", "params": {"path": "screenshot.png"}}

        m = re.match(r"(?:open|show)\s+(?:folder\s+)?(.+)", text, re.I)
        if m and (":" in m.group(1) or "\\" in m.group(1) or "/" in m.group(1)):
            return {"type": "open_folder", "params": {"path": m.group(1).strip()}}

        m = re.match(r"(?:create|make)\s+(?:a\s+)?folder\s+(.+)", text, re.I)
        if m:
            return {"type": "create_folder", "params": {"path": m.group(1).strip()}}

        m = re.match(r"(?:delete|remove)\s+file\s+(.+)", text, re.I)
        if m:
            return {"type": "delete_file", "params": {"path": m.group(1).strip()}}

        m = re.match(r"(?:run|execute)\s+(?:powershell\s+)?(.+)", text, re.I)
        if m:
            return {"type": "shell", "params": {"command": m.group(1).strip()}}

        if re.search(r"\b(?:put|send|make) (?:the )?(?:computer|pc) (?:to )?sleep\b", low) or re.search(r"\b(?:computer|pc) sleep\b", low) or low in {"sleep", "sleep computer", "sleep the computer", "put pc to sleep", "put computer to sleep"}:
            return {"type": "sleep_computer", "params": {}}

        # Local screen analysis: capture and OCR the screen; no ChatGPT required.
        if (
            re.search(r"\bwhat(?:\'s| is) on (?:my|the) screen\b", low)
            or re.search(r"\b(?:analyze|analyse|read|look at) (?:my|the) screen\b", low)
            or re.search(r"\bwhat do you see\b", low)
            or re.search(r"\bread (?:this|that) screen\b", low)
        ):
            return {"type": "analyze_screen", "params": {}}

        # Optional LLM fallback
        ollama_model = os.getenv("OLLAMA_MODEL", "").strip()
        if ollama_model:
            action = self._ollama_plan(text, ollama_model)
            if action:
                return action

        return None

    def _ollama_plan(self, text, model):
        system = """You are a Windows PC action planner. Return ONLY JSON.
Allowed action types:
open_app(name), open_url(url), type_text(text), hotkey(keys array),
screenshot(path), open_folder(path), create_folder(path), delete_file(path), shell(command).
Never perform an action yourself. Use the exact schema {"type":"...", "params":{...}}.
For ambiguous requests, return {"type":"shell","params":{"command":"echo AMBIGUOUS: ..."}} so the UI still requires confirmation."""
        try:
            r = requests.post(
                os.getenv("OLLAMA_URL", "http://127.0.0.1:11434") + "/api/chat",
                json={"model": model, "stream": False,
                      "messages": [{"role": "system", "content": system},
                                   {"role": "user", "content": text}]},
                timeout=30
            )
            content = r.json()["message"]["content"]
            return json.loads(content)
        except Exception:
            return None

    def manual_listen_once(self):
        def worker():
            self.listening = True
            path = None
            try:
                self.event_cb("I'm listening.")
                self._say("I'm listening.")
                text, path = self.capture_command()
                if text:
                    self.event_cb(f"Command: {text}")
                    action = self.parse_command(text)
                    if action:
                        self._handle_special_or_confirm(action)
            except Exception as e:
                self.event_cb(f"ERROR: {e}")
            finally:
                self.listening = False
                if path:
                    try:
                        os.unlink(path)
                    except OSError:
                        pass
        threading.Thread(target=worker, daemon=True).start()

    def _handle_special_or_confirm(self, action):
        if action.get('type')=='dictation_start':
            self.dictation_mode=True; self._say('Dictation is on. Speak into the active text box. Say stop dictation when finished.')
            threading.Thread(target=self._dictation_loop,daemon=True).start(); return
        if action.get('type')=='dictation_stop':
            self.dictation_mode=False; self._say('Dictation is off.'); return
        self.event_cb(("CONFIRM", action)); self._say(f"I can {describe(action).lower()}. Please confirm on screen.")
        while not self.stop_requested:
            time.sleep(0.1)
            if getattr(self, '_confirmed', None) is not None:
                confirmed=self._confirmed; self._confirmed=None
                if confirmed:
                    try:
                        result=execute(action); self.event_cb(result); self._say(result[:180])
                    except ActionError as e:
                        self.event_cb(f"Action failed: {e}"); self._say('That action failed.')
                else:
                    self.event_cb('Action cancelled.'); self._say('Cancelled.')
                break

    def _dictation_loop(self):
        while self.dictation_mode and not self.stop_requested:
            try:
                audio=self.record(7); text,path=self.transcribe(audio)
                try:
                    if not text: continue
                    low=text.strip().lower()
                    if low in {"stop dictation", "stop typing mode", "typing mode off", "dictation mode off"}:
                        self.dictation_mode=False; self._say('Dictation is off.'); continue
                    execute({"type":"type_text","params":{"text":text+' '}})
                finally:
                    try: os.unlink(path)
                    except OSError: pass
            except Exception as e:
                self.event_cb(f"Dictation error: {e}"); self.dictation_mode=False; break

    def run_once(self):
        if not self.listen_for_wake():
            return
        self.event_cb("I'm listening.")
        self._say("I'm listening.")
        text, path = self.capture_command()
        try:
            low_text = text.strip().lower()
            if low_text in {'start minecraft assist', 'start minecraft automation', 'minecraft assist'}:
                self.event_cb('MINECRAFT_ASSIST_START')
                return
            if low_text in {'stop minecraft assist', 'stop minecraft automation'}:
                self.event_cb('MINECRAFT_ASSIST_STOP')
                return
            try:
                speaker, _ = self.speaker.identify(path)
                self.current_speaker = speaker
            except Exception:
                pass
        finally:
            try: os.unlink(path)
            except OSError: pass

        if not text:
            self._say("I didn't catch that.")
            return

        self.event_cb(f"Command: {text}")
        action = self.parse_command(text)
        if not action:
            self._say("I understood the words, but I don't have a safe action for that yet.")
            return

        self._handle_special_or_confirm(action)
        self.listening = False

    def confirm_action(self, yes: bool):
        self._confirmed = yes

    def handle_wake(self):
        """Reset audio state after Windows resumes from sleep."""
        try:
            self.listening = False
            try:
                sd.stop()
            except Exception:
                pass
            self.event_cb("Computer woke up — Luna is reconnecting...")
            try:
                self._say("I'm back. Ready when you are.")
            except Exception:
                pass
            self.event_cb('Say "Hey Luna AI"')
        except Exception as e:
            self.event_cb(f"Wake recovery warning: {e}")

    def stop(self):
        self.stop_requested = True
