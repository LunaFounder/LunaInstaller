@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem Luna General Windows launcher
set "ENV=.venv"
if exist "luna_environment.txt" set /p ENV=<"luna_environment.txt"

if exist "%ENV%\Scripts\pythonw.exe" goto RUN

rem Find a usable system Python launcher without opening an interactive console.
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY where python >nul 2>&1 && set "PY=python"

if not defined PY (
  mshta.exe "%~dp0Install_Luna.hta"
  exit /b 0
)

rem Create Luna's private environment once.
if not exist "%ENV%\Scripts\python.exe" (
  echo Installing Luna General for the first time...
  %PY% -m venv "%ENV%"
  if errorlevel 1 (
    echo Luna could not create its private environment.
    echo See luna_startup.log if present.
    pause
    exit /b 1
  )
)

"%ENV%\Scripts\python.exe" -m pip install --disable-pip-version-check --no-input -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo Luna dependency installation failed.
  echo Check your internet connection and try again.
  pause
  exit /b 1
)

>"luna_environment.txt" echo %ENV%

:RUN
start "Luna" /b "%ENV%\Scripts\pythonw.exe" "%~dp0launch_luna.pyw"
exit /b 0
