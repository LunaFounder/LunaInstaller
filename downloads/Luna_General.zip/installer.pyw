import sys, subprocess, threading, tkinter as tk
from tkinter import messagebox
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV_FILE = ROOT / 'luna_environment.txt'
READY = ROOT / '.luna_ready'
REQ = ROOT / 'requirements.txt'
MODEL_NAME = 'tiny.en'

# Install in small stages rather than one large pip transaction.
STAGES = [
    ('Stage 1 of 8', 'Preparing Luna environment', ['PySide6>=6.8']),
    ('Stage 2 of 8', 'Installing numerical/audio foundations', ['numpy>=1.26', 'sounddevice>=0.5', 'soundfile>=0.12']),
    ('Stage 3 of 8', 'Installing Luna voice engine', ['faster-whisper>=1.1']),
    ('Stage 4 of 8', 'Installing Luna speech output', ['pyttsx3>=2.98']),
    ('Stage 5 of 8', 'Installing Windows/system helpers', ['psutil>=6.1', 'python-dotenv>=1.0', 'requests>=2.32']),
    ('Stage 6 of 8', 'Installing desktop control tools', ['pyautogui>=0.9.54', 'pyperclip>=1.9', 'pytesseract>=0.3.13']),
    ('Stage 7 of 8', 'Preparing Luna voice model', []),
    ('Stage 8 of 8', 'Finishing Luna General setup', []),
]

class Installer:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Luna General — Installer — Luna Founder')
        self.root.geometry('680x470')
        self.root.resizable(False, False)
        self.root.configure(bg='#08151c')

        tk.Label(self.root, text='Luna General', font=('Segoe UI', 28, 'bold'), fg='white', bg='#08151c').pack(pady=(22, 2))
        tk.Label(self.root, text='Staged installation — components are installed in small increments',
                 font=('Segoe UI', 10), fg='#9fb5be', bg='#08151c').pack()

        self.stage = tk.StringVar(value='Ready to begin.')
        self.detail = tk.StringVar(value='Click Install Luna to start the staged setup.')
        tk.Label(self.root, textvariable=self.stage, font=('Segoe UI', 13, 'bold'), fg='#71f7ff', bg='#08151c').pack(pady=(25, 6))
        tk.Label(self.root, textvariable=self.detail, font=('Segoe UI', 10), fg='white', bg='#08151c', wraplength=590).pack(pady=(0, 18))

        self.pb = tk.Canvas(self.root, width=600, height=18, bg='#20303a', highlightthickness=0)
        self.pb.pack()
        self.fill = self.pb.create_rectangle(0, 0, 0, 18, fill='#71f7ff', outline='')

        self.current = tk.StringVar(value='Stage 0 of 8')
        tk.Label(self.root, textvariable=self.current, font=('Segoe UI', 9), fg='#7f99a5', bg='#08151c').pack(pady=8)

        row = tk.Frame(self.root, bg='#08151c')
        row.pack(pady=24)
        self.btn = tk.Button(row, text='Install Luna', command=self.begin, width=20, height=2,
                             bg='#71f7ff', fg='#07131a', relief='flat')
        self.btn.pack(side='left', padx=8)
        tk.Button(row, text='Close', command=self.root.destroy, width=12, height=2,
                  bg='#263640', fg='white', relief='flat').pack(side='left', padx=8)

        tk.Label(self.root,
                 text='The first installation runs in several smaller steps. Later launches do not reinstall packages.',
                 font=('Segoe UI', 9), fg='#7f99a5', bg='#08151c', wraplength=600).pack(pady=(2, 0))

        self.root.mainloop()

    def set_status(self, stage, detail, percent):
        def update():
            self.stage.set(stage)
            self.detail.set(detail)
            self.pb.coords(self.fill, 0, 0, 600 * max(0, min(percent, 100)) / 100, 18)
        self.root.after(0, update)

    def choose_env(self):
        for name in ['.venv'] + [f'.venv_{i}' for i in range(2, 11)]:
            p = ROOT / name
            if (p / 'Scripts' / 'python.exe').exists():
                return p
            try:
                p.mkdir(exist_ok=True)
                return p
            except OSError:
                continue
        raise RuntimeError('Windows would not allow Luna to create its private environment here. Extract Luna to Documents and try again.')

    def begin(self):
        self.btn.config(state='disabled')
        threading.Thread(target=self.run, daemon=True).start()

    def pip_install(self, py, packages, label, base_percent, next_percent):
        if not packages:
            return
        for i, package in enumerate(packages):
            pct = base_percent + ((i + 1) / len(packages)) * (next_percent - base_percent)
            self.set_status(label, f'Installing {package}…', pct)
            subprocess.run(
                [str(py), '-m', 'pip', 'install', '--disable-pip-version-check', '--no-input', package],
                check=True,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
            )

    def run(self):
        try:
            env = self.choose_env()
            py = env / 'Scripts' / 'python.exe'
            pyw = env / 'Scripts' / 'pythonw.exe'

            if not py.exists():
                self.set_status('Stage 1 of 8', 'Creating Luna private environment…', 4)
                subprocess.run([sys.executable, '-m', 'venv', str(env)], check=True)

            # Install in intentionally separated increments.
            self.pip_install(py, STAGES[0][2], 'Stage 1 of 8 — Preparing Luna General', 2, 12)
            self.pip_install(py, STAGES[1][2], 'Stage 2 of 8 — Installing audio foundations', 12, 28)
            self.pip_install(py, STAGES[2][2], 'Stage 3 of 8 — Installing the voice engine', 28, 42)
            self.pip_install(py, STAGES[3][2], 'Stage 4 of 8 — Installing speech output', 42, 52)
            self.pip_install(py, STAGES[4][2], 'Stage 5 of 8 — Installing system helpers', 52, 65)
            self.pip_install(py, STAGES[5][2], 'Stage 6 of 8 — Installing desktop controls', 65, 78)

            self.set_status('Stage 7 of 8', 'Preparing the Luna voice model (this can take several minutes)…', 80)
            code = 'from faster_whisper import WhisperModel; WhisperModel("tiny.en", device="cpu", compute_type="int8")'
            subprocess.run([str(py), '-c', code], check=True, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))

            self.set_status('Stage 8 of 8', 'Creating Luna General shortcuts and startup settings…', 92)
            ENV_FILE.write_text(env.name, encoding='utf-8')
            READY.write_text('ready\n', encoding='utf-8')
            try:
                ps = ROOT / 'create_luna_shortcuts.ps1'
                if ps.exists():
                    subprocess.run(['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(ps)], check=False,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            except Exception:
                pass

            self.set_status('Installation complete', 'Luna General is ready. Launching the desktop app…', 100)
            self.root.after(900, lambda: self.launch(pyw))
        except Exception as e:
            self.root.after(0, lambda: (self.btn.config(state='normal'), messagebox.showerror('Luna General Installer — Luna Founder', f'Installation failed.\n\n{e}')))
            self.set_status('Installation stopped', 'See the error dialog for details.', 0)

    def launch(self, exe):
        try:
            launcher = ROOT / 'launch_luna.pyw'
            subprocess.Popen([str(exe), str(launcher if launcher.exists() else ROOT / 'app.py')], cwd=str(ROOT), creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            self.root.destroy()
        except Exception as e:
            messagebox.showerror('Luna General', f'Installed, but Luna could not start.\n\n{e}')

Installer()
