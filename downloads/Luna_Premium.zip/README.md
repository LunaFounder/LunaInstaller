# Luna Premium — $9.99

Publisher: Luna Founder
Wake phrase: **Hey Luna AI**

Includes the full code-drawn animated chibi Luna plus Premium desktop extensions.

Premium extensions include screen analysis, voice dictation, Voice Activated Apps, and Minecraft Assist.


CHIBI VTUBER UPDATE
The Luna window now uses the provided chibi character with VTuber-style live motion, blinking, speaking-mouth animation, listening indicators, and idle movement.
