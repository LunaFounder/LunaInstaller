import sys, threading, math, os, traceback
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QRectF, QPropertyAnimation, QEasingCurve, QPointF
from PySide6.QtGui import QColor, QPainter, QFont, QPixmap, QIcon, QPainterPath
from edition import EDITION, DISPLAY_NAME, PRICE
from PySide6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QHBoxLayout, QVBoxLayout, QFrame, QDialog, QComboBox, QLineEdit, QListWidget, QMessageBox, QFileDialog, QCheckBox

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
STARTUP_LOG = ROOT / 'luna_startup.log'

def log_error(prefix, exc=None):
    try:
        with STARTUP_LOG.open('a', encoding='utf-8') as f:
            f.write('\n' + '='*70 + '\n' + prefix + '\n')
            if exc: f.write(''.join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
    except Exception:
        pass


class LunaVisual(QWidget):
    """Image-backed chibi VTuber-style Luna with state-driven live animation."""
    def __init__(self):
        super().__init__()
        self.phase = 0.0
        self.state = 'idle'
        self.expression = 'neutral'
        self.blink = 0.0
        self.listening_level = 0.0
        self.speaking_level = 0.0
        self.pulse = 0.0
        self._pix = QPixmap(str(ROOT / 'assets' / 'luna_chibi_vtuber.png'))
        self.setFixedSize(248, 278)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(33)

    def set_state(self, state):
        state = str(state).lower().strip()
        if state not in {'idle', 'listening', 'speaking', 'processing', 'error', 'confirm'}:
            state = 'idle'
        self.state = state
        self.expression = {
            'idle': 'neutral', 'listening': 'focused', 'speaking': 'happy',
            'processing': 'focused', 'error': 'sad', 'confirm': 'surprised'
        }[state]
        self.update()

    def set_expression(self, expression):
        self.expression = str(expression).lower().strip()
        self.update()

    def tick(self):
        self.phase += 0.10
        self.pulse = (math.sin(self.phase * 2.2) + 1.0) / 2.0
        self.listening_level = (math.sin(self.phase * 5.8) + 1.0) / 2.0 if self.state == 'listening' else 0.0
        self.speaking_level = (math.sin(self.phase * 11.0) + 1.0) / 2.0 if self.state == 'speaking' else 0.0
        cycle = self.phase % 14.0
        self.blink = 1.0 if 9.6 < cycle < 9.90 else 0.0
        self.update()

    def _draw_image(self, p, rect):
        p.drawPixmap(rect, self._pix)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        W, H = self.width(), self.height()
        cx = W/2
        bob = math.sin(self.phase*2.0) * 3.2
        sway = math.sin(self.phase*0.9) * 2.2
        tilt = math.sin(self.phase*0.72) * 1.7
        scale = 1.0 + 0.015*math.sin(self.phase*1.35)
        if self.state == 'listening':
            scale += 0.010*self.pulse
        elif self.state == 'speaking':
            scale += 0.014*self.speaking_level

        # Animated aura and status ring.
        if self.state in {'listening','speaking','processing','confirm'}:
            rr = 112 + 8*self.pulse
            if self.state == 'listening':
                col=QColor(110,245,255,95+int(85*self.pulse))
            elif self.state == 'speaking':
                col=QColor(225,120,255,90+int(80*self.pulse))
            elif self.state == 'confirm':
                col=QColor(255,208,108,100+int(70*self.pulse))
            else:
                col=QColor(120,205,255,80+int(70*self.pulse))
            pen=p.pen(); pen.setWidthF(3.2); pen.setColor(col); p.setPen(pen); p.setBrush(Qt.NoBrush)
            p.drawEllipse(QRectF(cx-rr, 132-rr*0.72, rr*2, rr*1.44))

        # Small floating hearts/sparks.
        p.setPen(Qt.NoPen)
        for i in range(7):
            ang=self.phase*0.55+i*0.9
            x=cx+math.cos(ang)*(94+9*math.sin(ang*1.7))
            y=112+math.sin(ang*1.18)*88 - ((self.phase*7+i*9)%24)
            r=2.0 + 1.2*((math.sin(ang*2)+1)/2)
            col=QColor(255,170,232,75+int(85*self.pulse))
            if self.state=='listening': col=QColor(119,255,222,100+int(85*self.pulse))
            p.setBrush(col); p.drawEllipse(QRectF(x-r,y-r,2*r,2*r))

        # Character image with subtle VTuber head/body motion.
        base_w, base_h = 206, 206
        draw_w, draw_h = base_w*scale, base_h*scale
        x=cx-draw_w/2+sway
        y=24+bob
        p.save()
        p.translate(cx, 132+bob)
        p.rotate(tilt)
        p.translate(-cx, -(132+bob))
        self._draw_image(p, QRectF(x,y,draw_w,draw_h))

        # Blink overlay (skin-colored lids) only during blink cycle.
        if self.blink:
            skin=QColor(248,214,204,235)
            p.setBrush(skin); p.setPen(Qt.NoPen)
            p.drawRoundedRect(QRectF(cx-49+sway, 99+bob, 34, 13), 7,7)
            p.drawRoundedRect(QRectF(cx+15+sway, 99+bob, 34, 13), 7,7)

        # Tiny talking mouth overlay. The source image already has a smile; this adds a live VTuber mouth.
        if self.state == 'speaking':
            mh=8+11*self.speaking_level
            p.setBrush(QColor(65,28,53,240)); p.drawEllipse(QRectF(cx-8+sway, 137+bob-mh/2, 16, mh))
            p.setBrush(QColor(255,145,190,220)); p.drawEllipse(QRectF(cx-5+sway, 139+bob, 10, max(2,mh*0.33)))
        elif self.expression == 'sad':
            pen=p.pen(); pen.setColor(QColor(89,45,63,230)); pen.setWidthF(2.2); p.setPen(pen); p.setBrush(Qt.NoBrush)
            p.drawArc(QRectF(cx-11+sway, 143+bob, 22, 14), 25*16, 130*16)
        p.restore()

        # Listening waveform / speech bars.
        if self.state in {'listening','speaking'}:
            bars=10; bw=4; gap=4
            total=bars*bw+(bars-1)*gap
            start=cx-total/2
            for i in range(bars):
                phase=self.phase*9+i*0.72
                level=(math.sin(phase)+1)/2
                if self.state=='listening': level=0.25+0.75*level
                else: level=0.12+0.88*level
                hh=7+26*level
                col=QColor(92,255,218,180+int(65*self.pulse)) if self.state=='listening' else QColor(199,146,255,180+int(65*self.pulse))
                p.setBrush(col); p.setPen(Qt.NoPen)
                p.drawRoundedRect(QRectF(start+i*(bw+gap), 238-hh, bw, hh), 2,2)

        # Status chip.
        labels={'idle':'STANDBY','listening':"I'M LISTENING",'speaking':'SPEAKING','processing':'THINKING…','confirm':'CONFIRM','error':'ERROR'}
        colors={'idle':QColor(160,150,255,210),'listening':QColor(86,255,214,245),'speaking':QColor(222,145,255,240),'processing':QColor(114,210,255,235),'confirm':QColor(255,209,112,240),'error':QColor(255,119,150,240)}
        p.setBrush(QColor(16,13,31,215)); p.setPen(Qt.NoPen); p.drawRoundedRect(QRectF(cx-70,244,140,25),12,12)
        pen=p.pen(); pen.setColor(colors[self.state]); p.setPen(pen); p.setFont(QFont('Segoe UI',8,QFont.Bold))
        p.drawText(QRectF(cx-68,244,136,25), Qt.AlignCenter, labels[self.state])


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f'{DISPLAY_NAME} — Luna Founder')
        icon=ROOT/'assets'/'luna.ico'
        if icon.exists(): self.setWindowIcon(QIcon(str(icon)))
        flags=Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(260,318)
        self.pending_action=None; self.assistant=None; self.minecraft_assist=None

        self.canvas=LunaVisual()
        self.canvas.setParent(self)
        self.canvas.move(6, 4)

        self.status=QLabel(f'Luna Founder\n{DISPLAY_NAME.replace("Luna ", "")} Ready')
        self.status.setFont(QFont('Segoe UI', 8, QFont.Bold)); self.status.setStyleSheet('color:white;background:transparent')
        self.status.setFixedHeight(32)
        self.indicator=QLabel('●')
        self.indicator.setFont(QFont('Segoe UI', 12, QFont.Bold)); self.indicator.setStyleSheet('color:#44ffc1;background:transparent')

        self.mic=QPushButton('🎙'); self.mic.setFixedSize(32,32)
        self.mic.setStyleSheet('QPushButton{background:#0d9d82;color:white;border:0;border-radius:14px;font-size:12px} QPushButton:hover{background:#12b694}')
        self.mic.clicked.connect(self.toggle_listening)
        self.settings=QPushButton('⚙'); self.settings.setFixedSize(28,28)
        self.settings.setStyleSheet('QPushButton{background:#17252b;color:#d8ffff;border:1px solid #24444d;border-radius:16px;font-size:14px} QPushButton:hover{background:#20373f}')
        self.settings.clicked.connect(self.open_settings)

        panel=QFrame(self); panel.setGeometry(8,276,244,36)
        panel.setStyleSheet('QFrame{background:rgba(5,28,35,235);border:1px solid rgba(41,255,215,85);border-radius:27px}')
        h=QHBoxLayout(panel); h.setContentsMargins(6,1,5,1); h.setSpacing(4)
        h.addWidget(self.indicator)
        h.addWidget(self.status,1)
        h.addWidget(self.mic)
        h.addWidget(self.settings)

        self.confirm=QFrame(self); self.confirm.setGeometry(8,228,244,44); self.confirm.hide()
        self.confirm.setStyleSheet('QFrame{background:rgba(4,20,26,245);border:1px solid #48ffd0;border-radius:14px} QLabel{color:white} QPushButton{background:#48d6b0;color:#061217;border:0;border-radius:8px;padding:5px 9px}')
        ch=QHBoxLayout(self.confirm); ch.setContentsMargins(6,4,6,4)
        self.confirm_text=QLabel(''); self.confirm_text.setWordWrap(True); ch.addWidget(self.confirm_text,1)
        y=QPushButton('OK'); n=QPushButton('No'); y.clicked.connect(lambda:self.respond(True)); n.clicked.connect(lambda:self.respond(False)); ch.addWidget(y); ch.addWidget(n)

        self.move_to_corner(); self.show(); QTimer.singleShot(80,self.start_background_services)

    def move_to_corner(self):
        screen=QApplication.primaryScreen()
        if screen:
            geo=screen.availableGeometry(); self.move(geo.left()+12, geo.bottom()-self.height()-12)

    def toggle_listening(self):
        if self.assistant and not self.assistant.listening:
            self.assistant.manual_listen_once()
        elif self.assistant:
            self.assistant.listening=False
            self.handle_assistant_event('Say "Hey Luna AI"')

    def start_background_services(self):
        try:
            from minecraft_assist import MinecraftAssist
            self.minecraft_assist=MinecraftAssist(self.handle_assistant_event)
        except Exception as e:
            log_error('Minecraft Assist could not load.',e)
        threading.Thread(target=self._initialize_assistant,daemon=True).start()

    def _initialize_assistant(self):
        try:
            self.handle_assistant_event('Loading Luna Premium voice system…')
            from assistant import VoiceAssistant
            self.assistant=VoiceAssistant(self.handle_assistant_event)
            self.handle_assistant_event('Ready. Say "Hey Luna AI".')
            threading.Thread(target=self.loop,daemon=True).start()
        except Exception as e:
            log_error('Voice assistant failed to initialize.',e)
            self.handle_assistant_event(f'Voice system failed to start: {e}')

    def handle_assistant_event(self,msg): QTimer.singleShot(0,lambda m=msg:self._handle_assistant_event(m))
    def _handle_assistant_event(self,msg):
        if isinstance(msg,tuple) and msg and msg[0]=='CONFIRM':
            self.pending_action=msg[1]
            self.confirm_text.setText(str(msg[1]))
            self.confirm.show()
            self.canvas.set_state('confirm')
            return
        if isinstance(msg,tuple) and msg and msg[0]=='MINECRAFT_RESPAWN_CONFIRM':
            self.pending_action={'type':'minecraft_respawn_assist'}
            self.confirm_text.setText(msg[1]); self.confirm.show(); self.canvas.set_state('confirm'); return
        if msg=='MINECRAFT_ASSIST_START' and self.minecraft_assist: self.minecraft_assist.start(); return
        if msg=='MINECRAFT_ASSIST_STOP' and self.minecraft_assist: self.minecraft_assist.stop(); return
        text=str(msg); self.status.setText('Luna Founder\n'+text)
        low=text.lower()
        if 'speaking' in low:
            self.status.setText('Luna Founder\nSpeaking')
            self.indicator.setStyleSheet('color:#b59cff;background:transparent')
            self.canvas.set_state('speaking')
        elif 'thinking' in low or 'processing' in low:
            self.status.setText('Luna Founder\nThinking…')
            self.indicator.setStyleSheet('color:#6fd6ff;background:transparent')
            self.canvas.set_state('processing')
        elif low.startswith('command:'):
            self.status.setText('Luna Founder\nThinking…')
            self.indicator.setStyleSheet('color:#6fd6ff;background:transparent')
            self.canvas.set_state('processing')
        elif 'listening' in low:
            self.status.setText("Luna Founder\nI'm listening")
            self.indicator.setStyleSheet('color:#59ffd2;background:transparent')
            self.canvas.set_state('listening')
        elif 'ready' in low or 'standby' in low:
            self.status.setText('Luna Founder\nReady')
            self.indicator.setStyleSheet('color:#44ffc1;background:transparent')
            self.canvas.set_state('idle')
        elif 'failed' in low or 'error' in low:
            self.status.setText('Luna Founder\nOops...')
            self.indicator.setStyleSheet('color:#ff7a8b;background:transparent')
            self.canvas.set_state('error')
        else:
            self.indicator.setStyleSheet('color:#60e8d0;background:transparent')

    def open_settings(self):
        try:
            from voice_apps import scan_apps, get_commands, set_command, remove_command
        except Exception as e:
            QMessageBox.warning(self,'Luna Founder',str(e)); return
        dlg=QDialog(self); dlg.setWindowTitle('Luna Premium — Settings — Luna Founder'); dlg.resize(520,470)
        dlg.setStyleSheet('QDialog{background:#09181d;color:white} QLabel{color:white} QLineEdit,QComboBox,QListWidget{background:#10262d;color:white;border:1px solid #25515a;border-radius:7px;padding:6px} QPushButton{background:#1e8f79;color:white;border:0;border-radius:8px;padding:8px 11px}')
        v=QVBoxLayout(dlg); v.addWidget(QLabel('Luna Premium'))
        v.addWidget(QLabel('Voice Activated Apps — assign a voice phrase to any detected app.'))
        apps=scan_apps(); combo=QComboBox(); combo.addItems([Path(p).stem for p in apps.values()]); v.addWidget(combo)
        phrase=QLineEdit(); phrase.setPlaceholderText('Example: open Spotify'); v.addWidget(phrase)
        row=QHBoxLayout(); save=QPushButton('Save Command'); rem=QPushButton('Remove Command'); row.addWidget(save); row.addWidget(rem); v.addLayout(row)
        listing=QListWidget(); v.addWidget(listing,1)
        close=QPushButton('Close'); close.clicked.connect(dlg.accept); v.addWidget(close)
        def refresh():
            listing.clear(); [listing.addItem(f'{p} → {Path(path).stem}') for p,path in sorted(get_commands().items())]
        def load(n):
            phrase.clear()
            for p,path in get_commands().items():
                if Path(path).stem.lower()==n.lower(): phrase.setText(p); break
        def save_cmd():
            try: set_command(combo.currentText(),phrase.text()); refresh(); QMessageBox.information(dlg,'Luna','Command saved.')
            except Exception as e: QMessageBox.warning(dlg,'Luna',str(e))
        def rem_cmd():
            if phrase.text().strip(): remove_command(phrase.text().strip()); refresh(); phrase.clear()
        combo.currentTextChanged.connect(load); save.clicked.connect(save_cmd); rem.clicked.connect(rem_cmd); refresh(); load(combo.currentText())

        # Code-drawn chibi character — no image asset is required.
        char_box = QFrame(dlg)
        cbv = QVBoxLayout(char_box)
        cbv.setContentsMargins(0,8,0,4)
        cbcbv.addWidget(QLabel('Chibi VTuber Character — image-backed, state-driven animation.'))
        cbv.addWidget(QLabel('Idle, blinking, listening, speaking, thinking, confirmation, and error states.'))
        v.insertWidget(v.count()-1, char_box)

        dlg.exec()

    def respond(self,yes):
        self.confirm.hide()
        self.canvas.set_state('processing')
        if self.pending_action and self.pending_action.get('type')=='minecraft_respawn_assist':
            if yes and self.minecraft_assist: self.minecraft_assist.confirm_respawn()
        elif self.assistant: self.assistant.confirm_action(yes)
        self.pending_action=None

    def loop(self):
        while self.assistant and not self.assistant.stop_requested:
            try: self.assistant.run_once()
            except Exception as e:
                log_error('Voice loop error.',e); self.handle_assistant_event(f'ERROR: {e}'); break
    def closeEvent(self,e):
        try:
            if self.minecraft_assist: self.minecraft_assist.stop()
            if self.assistant: self.assistant.stop()
        except Exception as exc: log_error('Shutdown error.',exc)
        e.accept()

if __name__=='__main__':
    try:
        app=QApplication(sys.argv); app.setApplicationName('Luna'); app.setDesktopFileName('luna')
        icon=ROOT/'assets'/'luna.ico'
        if icon.exists(): app.setWindowIcon(QIcon(str(icon)))
        w=MainWindow(); w.show(); sys.exit(app.exec())
    except Exception as e:
        log_error('Fatal application startup error.',e); raise
